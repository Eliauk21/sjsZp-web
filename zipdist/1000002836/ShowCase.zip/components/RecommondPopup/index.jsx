import React, { useMemo, useRef } from 'react';
import { Swiper, SwiperItem, View, Image } from '@tarojs/components'
import style from './index.module.scss';


const RecommondPopup = ({ recommondList = [], onClose, onToLJLJ, onAddCart }) => {
  const touchStartX = useRef(0);
  const touchStartY = useRef(0);

  // 将商品分页，每页4个商品
  const paginatedItems = useMemo(() => {
    const items = recommondList || [];
    const pages = [];
    for (let i = 0; i < items.length; i += 4) {
      pages.push(items.slice(i, i + 4));
    }
    return pages;
  }, [recommondList]);

  const close = () => {
    onClose && onClose();
  };

  const toLJLJ = () => {
    onToLJLJ && onToLJLJ(1);
  };

  // 添加购物车方法
  const addCart = (item) => {
    const skuIds = item[0].skus.map((sku) => sku.skuId);
    onAddCart && onAddCart(skuIds, 1);
  };

  // 处理触摸开始事件
  const handleTouchStart = (e) => {
    const target = e.currentTarget;
    const itemCount = target.children.length;
    // 只有当商品数量大于3个时才处理触摸事件
    if (itemCount > 3) {
      touchStartX.current = e.touches[0].clientX;
      touchStartY.current = e.touches[0].clientY;
    }
  };

  // 处理触摸移动事件
  const handleTouchMove = (e) => {
    const touchX = e.touches[0].clientX;
    const touchY = e.touches[0].clientY;

    const deltaX = Math.abs(touchX - touchStartX.current);
    const deltaY = Math.abs(touchY - touchStartY.current);

    // 如果水平滑动距离大于垂直滑动距离，则阻止事件冒泡到 Swiper
    if (deltaX > deltaY) {
      e.stopPropagation();
    }
  };

  // 处理触摸结束事件
  const handleTouchEnd = () => {
    // 清空触摸起始位置
    touchStartX.current = 0;
    touchStartY.current = 0;
  };


  return (
    <View className={style['popup']} id="RecommondPopup" onClick={(e) => {
      e.stopPropagation();
    }}>
      <Image
        src="//img10.360buyimg.com/imgzone/jfs/t1/280484/33/17243/918/67f72edfF8b7f296b/989835f01adf2c9f.png"
        alt=""
        className={style['close']}
        onClick={close}
      />
      <View className={style['popup-bk']}>
        <Image
          className={style['title']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/337035/3/8591/5634/68bfbe49F2aa227c4/ec86ae855817323a.png"
        />
        {/* 领券立减 */}
        <Image
          className={style['btn']}
          onClick={toLJLJ}
          src="//img10.360buyimg.com/imgzone/jfs/t1/328854/24/17916/11339/68bfbe48Feb39c0b9/c815e850ccd79c6e.png"
        />
        {recommondList && recommondList.length > 0 && (
          <Swiper
            autoplay={false}
            indicatorDots
            indicatorActiveColor='#FC4446'
            style={{ overflow: 'hidden', height: '84%', width: '90%', top: '1.8rem', left: '0.6rem', position: 'relative', }}>
            {paginatedItems.map((pageItems, pageIndex) => (
              <SwiperItem key={pageIndex}>
                {pageItems.map((item, index) => (
                  <View className={style['skuList-item']} key={index}>
                    <View className={style['jiaobiao']}>
                      {pageIndex == 0 ? '0'+ (index+1) :
                        pageIndex == 1 ? '0'+ (index + 5) :
                          (pageIndex == 2 && index >=1) ? 10 : '09'}
                    </View>
                    {item[0].skus.length > 3 && (
                      <Image
                        className={style['left-pic']}
                        src="//img10.360buyimg.com/imgzone/jfs/t1/329739/5/11144/583/68bfbe4aF2e7949d8/1a78b65b1a7c1570.png"
                        alt=""
                      />
                    )}
                    <View
                      className={style['sku-list']}
                      onTouchStart={handleTouchStart}
                      onTouchMove={handleTouchMove}
                      onTouchEnd={handleTouchEnd}
                    >
                      {item[0].skus.map((sku, skuIndex) => (
                        <View className={style['sku-item']} key={skuIndex}>
                          <View className={style['img']}>
                            <Image src={sku.skuMainPicture} alt=""/>
                            <View className={style['sku-price']}>￥{sku.jdPrice}</View>
                          </View>
                          {skuIndex !== item[0].skus.length - 1 && (
                            <Image
                              src="//img10.360buyimg.com/imgzone/jfs/t1/334114/24/11082/252/68bfbe4aF41ec88ba/d34c3e3bc2846af4.png"
                              alt=""
                              className={style['add']}
                            />
                          )}
                        </View>
                      ))}
                    </View>
                    {item[0].skus.length > 3 && (
                      <Image
                        className={style['right-pic']}
                        src="//img10.360buyimg.com/imgzone/jfs/t1/301237/39/19743/632/68bfbe4aFbc6bdc64/35fd989a1f1baa58.png"
                        alt=""
                      />
                    )}
                    <View className={style['sku-tips']}>
                      <View className={style['line1']}>
                        节省<span style={{ fontSize: '0.56rem', color: '#FF481A' }}>{item[0].difPrice}</span>
                      </View>
                      <View className={style['line2']}>
                        合计：
                        <span style={{ fontSize: '0.42rem', color: '#FF481A' }}>
                            ￥{item[0].skus.reduce((acc, cur) => acc + +cur.cxPrice, 0).toFixed(2)}
                          </span>
                      </View>
                      <View className={style['line3']} onClick={() => addCart(item)}>
                        加购({item[0].num}件）
                      </View>
                    </View>
                  </View>
                ))}
              </SwiperItem>
            ))}
          </Swiper>
        )}
      </View>
    </View>
  );
};

export default RecommondPopup;
