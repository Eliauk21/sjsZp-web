import React, { useState, useEffect, useRef } from 'react';
import { util } from '@conecli/cone-render/api'

import { Swiper, SwiperItem, View, Image } from '@tarojs/components'
import style from "./index.module.scss";

const BagPopup = ({ bagList = [], onClose, onClickBtn, onDelSku, onSelectSku, onAddCart }) => {

  const [copyBagList, setCopyBagList] = useState([])

  useEffect(() => {
    setCopyBagList(bagList.map(v => ({...v, select: false})))
  }, [bagList])

  // 将商品分页，每页3个商品
  const paginatedItems = () => {
    const pages = [];
    for (let i = 0; i < copyBagList.length; i += 3) {
      pages.push(copyBagList.slice(i, i + 3));
    }
    return pages;
  };

  // 计算已选商品数量
  const selectedItemsLength = () => {
    return copyBagList.filter(item => item.select === true).length;
  };

  // 计算总价
  const totalPrice = () => {
    let total = 0;
    copyBagList.forEach(item => {
      if (item.select === true) {
        if (item.cxPrice == null) {
          total += +item.jdPrice * 1;
        } else {
          total += +item.cxPrice * 1;
        }
      }
    });
    return total.toFixed(2);
  };

  // 计算节省金额
  const jsPrice = () => {
    let total = 0;
    copyBagList.forEach(item => {
      if (item.select === true) {
        if (item.cxPrice == null) {
          total += 0;
        } else {
          total += item.jdPrice * 1 - +item.cxPrice * 1;
        }
      }
    });
    return +total.toFixed(2);
  };

  const addCart = () => {
    // 加入购物车之后，商品还在购物袋
    const items = copyBagList || [];
    const count = items.filter((item) => item.select === true).length;
    if (count === 0) {
      util.showFailToast({
        title: '请选择商品~',
        duration: 3000
      })
      return;
    }
    const skuIds = items.filter((item) => item.select === true).map((item) => item.skuId);
    onAddCart(skuIds, 0)
  };

  const handelDelSku = (skuId) => {
    const updatedBagList = copyBagList.filter(item => item.skuId !== skuId);
    setCopyBagList(updatedBagList);
    onDelSku(skuId);
  }

  const handleSelectSku = (skuId) => {
    onSelectSku(skuId);
    const newBagList = copyBagList.map((item)=> {
      if (item.skuId === skuId) {
        return { ...item, select: !item.select };
      }
      return item;
    })
    setCopyBagList(newBagList);
  };

  return (
    <View className={style['popup']} id="BagPopup" onClick={(e) => {
      e.stopPropagation();
    }}>
      <Image
        src="//img10.360buyimg.com/imgzone/jfs/t1/280484/33/17243/918/67f72edfF8b7f296b/989835f01adf2c9f.png"
        alt=""
        className={style['close']}
        onClick={onClose}
      />
      <View className={style['popup-bk']}>
        <Image
          className={style['title']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/345567/3/1126/5875/68bfbe46F0079d0f8/4d5c8da6acb82014.png"
        />
        <Image
          className={style['btn']}
          onClick={() => onClickBtn(2)}
          src="//img10.360buyimg.com/imgzone/jfs/t1/328854/24/17916/11339/68bfbe48Feb39c0b9/c815e850ccd79c6e.png"
        />

        {
          paginatedItems() && paginatedItems().length > 0 && <Swiper
            autoplay={false}
            indicatorDots
            indicatorActiveColor='#FC4446'
            style={{ overflow: 'hidden', height: '70%', width: '90%', top: '1.8rem', left: '0.6rem', position: 'relative', }}
          >
            { paginatedItems().map((pageItems, pageIndex) => {
              return (
                <SwiperItem key={pageIndex}>
                  {pageItems.map((item, index) => (
                    <View className={style['product-item']} key={index}>
                      <Image
                        onClick={() => handleSelectSku(item.skuId)}
                        className={style['sel-btn']}
                        src={item.select === false
                          ? "//img10.360buyimg.com/imgzone/jfs/t1/332215/27/11224/3048/68bfbe47Fa59e5579/36f6fc8e00d195b2.png"
                          : "//img10.360buyimg.com/imgzone/jfs/t1/343427/2/1276/1691/68bfbe47F23c73e05/e94e2f624e23fab1.png"
                        }
                      />
                      <Image
                        src={item.image || item.skuMainPicture}
                        alt={item.skuName}
                        className={style['product-image']}
                      />
                      <View className={style['product-name']}>{item.skuName}</View>
                      <View className={style['product-price']}>
                        <span style={{ fontSize: '0.51rem' }}>￥</span>
                        { item.cxPrice == null ? item.jdPrice : item.cxPrice }
                      </View>
                      <Image
                        onClick={() => handelDelSku(item.skuId)}
                        className={style['del-btn']}
                        src="//img10.360buyimg.com/imgzone/jfs/t1/338418/18/8719/896/68bfbe47F4a33145a/95b1945d35117d89.png"
                      />
                    </View>
                  ))}
                </SwiperItem>
              )
            })}
          </Swiper>

        }

        {copyBagList && copyBagList.length > 0 && (
          <View className={style['sku-tips']}>*您的最终优惠金额将在付款页面呈现</View>
        )}

        {
          jsPrice() > 0 ?
          <View className={style['sku-bottom']}>
            <View className={style['total-price']}>
              已选{selectedItemsLength()}件，合计：
              <span style={{ color: '#FF481A', fontWeight: 'bold' }}>
                <span style={{ fontSize: '0.37rem' }}>￥</span>
                {totalPrice()}
              </span>
            </View>
            <View className={style['total-js']}>
              预计节省了
              <span style={{ color: '#FF481A', fontWeight: 'bold' }}>
                {jsPrice()}
              </span>
            </View>
            <View className={style['add-cart']} onClick={addCart}>加购</View>
          </View>
          :
          <View className={style['sku-bottom']}>
            <View className={style['total-price1']}>
              已选{selectedItemsLength()}件，合计：
              <span style={{ color: '#FF481A', fontWeight: 'bold' }}>
                <span style={{ fontSize: '0.37rem' }}>￥</span>
                {totalPrice()}
              </span>
            </View>
            <View className={style['add-cart']} onClick={addCart}>加购</View>
          </View>
        }
        
      </View>
    </View>
  );
};

export default BagPopup;
