import React from 'react';
import { View, Image } from '@tarojs/components'
import style from './index.module.scss';
import { isvStorage, shopMember, util} from "@conecli/cone-render/api";

const OpenCardPopup = ({ onClose }) => {
  const { oneKeyJoinMember } = shopMember
  const lzUtils = isvStorage.getItem('lzUtilsShowcase');
  const header = isvStorage.getItem('headerShowcase');

  const getBeaconBehaviors = () => {
    try {
      lzUtils.httpRequestPoint({
        'Pin-Token': header['Pin-Token'],
        'Activity-Id': header['Activity-Id'] ,
        'Activity-Type': '10019',
        'Template-Code': '',
        reserveJsVersion: '',
        reserveEnvInfo: '',
        reserveClientTyp: 'h5',
        reserveFlowType: '1',
        reserveIsvToken: header['Pin-Token'],
        isvToken: header['Pin-Token'],
      });
    } catch (e) {
      console.error("Beacon 发送异常:", e);
    }
  };

  const onOpenCard = async () => {
    if (lzUtils?.isInitialized) {
      try {
        const isJoinMemberSuccess = await oneKeyJoinMember()
        if (isJoinMemberSuccess) {
          getBeaconBehaviors();
        }
      } catch (error) {
        if (error?.message) {
          util.showFailToast({
            title: error?.message,
            duration: 3000
          })
        }
      }
    }
  }


  return (
    <View className={style['rule-popup']} onClick={(e) => {
      e.stopPropagation();
    }}>
      <View className={style['rule-bk']}>
        <Image
          src="//img10.360buyimg.com/imgzone/jfs/t1/280484/33/17243/918/67f72edfF8b7f296b/989835f01adf2c9f.png"
          alt=""
          className={style['close']}
          onClick={onClose}
        />
        <View className={style['title']}>非常抱歉，您还未加入会员</View>
        <View className={style['content']}>加入会员才能参与领取活动哦</View>
        <View className={style['openCard']} onClick={onOpenCard}>立即入会</View>
      </View>
    </View>
  );
};

export default OpenCardPopup;
