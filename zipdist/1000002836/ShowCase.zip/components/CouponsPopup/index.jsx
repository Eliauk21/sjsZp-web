import React, { useState, useEffect, useRef } from 'react';
import { Swiper, SwiperItem, View, Image } from '@tarojs/components'
import style from './index.module.scss';
import {isvStorage, util} from "@conecli/cone-render/api";

const CouponsPopup = ({ fromType = 1, activityInfo, onClose, onBackSSD, onToTJZH, onCheckOutCondition }) => {
  const lzUtils = isvStorage.getItem('lzUtilsShowcase');
  const header = isvStorage.getItem('headerShowcase');

  const [couponList, setCouponList] = useState([]);

  // 将商品分页，每页4个商品
  const paginatedItems = () => {
    const pages = [];
    for (let i = 0; i < couponList.length; i += 4) {
      pages.push(couponList.slice(i, i + 4));
    }
    return pages;
  };

  const handleClose = () => {
    if (onClose) onClose();
  };

  const handleBackSSD = () => {
    if (onBackSSD) onBackSSD();
  };

  const handleToTJZH = () => {
    if (onToTJZH) onToTJZH();
  };

  const state = useRef(true);
  // 领取优惠券
  const getCoupon = async (couponIds, type) => {
    // 防止连点
    if (!state.current) return;
    state.current = false;
    const result = await onCheckOutCondition(header);
    if (!result) return;
    try {
      const {data} = await lzUtils.postUrl('/10119/receiveCoupon', {
        couponIds,
        type,
      }, header);
      if (data.code === 0) {
        await getMoreCouponList(header);
        util.showSuccessToast({
          title: '领取成功',
          duration: 3000
        })
      } else {
        util.showFailToast({
          title: data.message,
          duration: 3000
        })
      }
    } catch (error) {
      if (error?.message) {
        util.showFailToast({
          title: error.message,
          duration: 3000
        })
      }
    } finally {
      state.current = true;
    }
  };

  const getMoreCouponList = async (header) => {
    try {
      const { data } = await lzUtils.postUrl('/10119/getMoreCouponList', {}, header);
      const couponList = data.map((item) => ({
        ...item,
        stair: item.stair ? JSON.parse(item.stair) : [],
      }));
      setCouponList(couponList);
    } catch (error) {
      if (error?.message) {
        util.showFailToast({
          title: error?.message,
          duration: 3000
        })
      }
    }
  };

  useEffect(() => {
    getMoreCouponList(header);
  }, [])

  return (
    <View className={style['CouponsPopup']} onClick={(e) => {
      e.stopPropagation();
    }}>
      <Image
        src="//img10.360buyimg.com/imgzone/jfs/t1/280484/33/17243/918/67f72edfF8b7f296b/989835f01adf2c9f.png"
        alt=""
        className={style['close']}
        onClick={handleClose}
      />
      <View className={style['popup-bk']}>
        <Image
          className={style['title']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/325205/27/17806/6473/68bfbe48Ff0bd5d73/67a373a21e3ddcc4.png"
        />
        {/* 推荐组合/省钱袋 */}
        {(fromType === 1 && activityInfo.orderingSku == 1) ? (
          <Image
            className={style['btn']}
            onClick={handleToTJZH}
            src="//img10.360buyimg.com/imgzone/jfs/t1/325914/14/17327/10457/68bfbe49F61b90a85/9b4e0def218013c8.png"
          />
        ) : <Image
          className={style['btn']}
          onClick={handleBackSSD}
          src="//img10.360buyimg.com/imgzone/jfs/t1/351060/28/1246/11039/68bfbe49F9e352d64/b7f437e26588e689.png"
        />}
        {couponList && couponList.length > 0 &&
          <View className={style['swiper-container']} style={{overflow: 'hidden'}}>
            <Swiper
              autoplay={false}
              indicatorDots
              indicatorActiveColor='#FC4446'
              style={{ overflow: 'unset', height: '100%' }}
            >
              {paginatedItems().map((pageItems, pageIndex) => (
                <SwiperItem key={pageIndex} className={style['pageSwiperItem']}>
                  {pageItems.map((item, index) => (
                    <View className={style['coupon-item']} key={index}>
                      <View className={style['coupon-money']} style={{fontSize: item.discountType === 1 ? '1.2rem' : '1.2rem'}}>
                        {item.discountType === 1 ? (
                          <>
                            <span style={{fontSize: '0.6rem'}}>￥</span>
                            {item.couponDiscount}
                          </>
                        ) : (
                          <>
                            {item.stair && item.stair[item.stair?.length - 1].discount}
                            <span style={{fontSize: '0.6rem'}}>折</span>
                          </>
                        )}
                      </View>
                      <View className={style['coupon-name']}>满{item.couponQuota}可用</View>
                      <View className={style['coupon-time']}>
                        {item.expireType === 5
                          ? `${item.startTimeStr}至${item.endTimeStr}`
                          : `领券后${item.couponValidateDay}天有效`}
                      </View>
                      <View className={style['coupon-rangeType']}>
                        {item.rangeType === 1 ? '全部商品可用' : '部分商品可用'}
                      </View>
                      {
                        item.status !== 1 ? <Image className={style['get-btn']} onClick={() => getCoupon([item.id], 1)} src="//img10.360buyimg.com/imgzone/jfs/t1/333047/25/11154/10931/68bfbe48Fe251c47b/73e4021f02708ca4.png" />
                          :<Image className={`${style['get-btn']} ${style['disabled-btn']}`} src="//img10.360buyimg.com/imgzone/jfs/t1/333047/25/11154/10931/68bfbe48Fe251c47b/73e4021f02708ca4.png" />
                      }
                    </View>
                  ))}
                </SwiperItem>
              ))}
            </Swiper>
          </View>
        }
      </View>
    </View>
  );
};

export default CouponsPopup;
