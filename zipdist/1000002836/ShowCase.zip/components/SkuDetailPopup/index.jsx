import React from 'react';
import { track, jump } from '@conecli/cone-render/api'
import { View, Image } from '@tarojs/components'
import style from './index.module.scss';

const SkuDetailPopup = ({currentSku, currentIndex,currentShelf, onClose, onAddBagNow, floorData}) => {
  const close = () => {
    onClose();
  };

  const gotoSkuPage = (skuId) => {
    const trackEventInfo = track.getIsvClickEventInfo(floorData)
    jump.business.jdJumpToProduct(skuId, trackEventInfo)
  };

  const gotoSKU = () => {
    gotoSkuPage(currentSku.skuId);
  };

  const addBagNow = () => {
    onAddBagNow(currentSku, currentIndex, currentShelf);
  };

  return (
    <View className={style['popup']} id="SkuDetailPopup" onClick={(e) => {
      e.stopPropagation();
    }}>
      <Image
        src="//img10.360buyimg.com/imgzone/jfs/t1/280484/33/17243/918/67f72edfF8b7f296b/989835f01adf2c9f.png"
        alt=""
        className={style['close']}
        onClick={close}
      />
      <View className={style['popup-bk']}>
        <Image
          className={style['skuMainPicture']}
          src={currentSku.skuMainPicture}
          alt=""
        />
        <View className={style['skuName']}>{currentSku.skuName}</View>
        <View className={style['jdPrice']}>
          <span style={{ fontSize: '0.75rem' }}>￥</span>
          {currentSku.jdPrice}
        </View>
        <Image
          src="//img10.360buyimg.com/imgzone/jfs/t1/344154/1/1293/22325/68bfbe46F685e49ac/094efafa52b75286.png"
          className={style['btn1']}
          onClick={gotoSKU}
          alt=""
        />
        <Image
          src="//img10.360buyimg.com/imgzone/jfs/t1/342354/27/1332/28271/68bfbe47Fa419beaa/c661b263d3ed062a.png"
          className={style['btn2']}
          onClick={addBagNow}
          alt=""
        />
      </View>
    </View>
  );
};

export default SkuDetailPopup;
