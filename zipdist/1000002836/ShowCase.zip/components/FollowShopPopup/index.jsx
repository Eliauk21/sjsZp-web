import React, { useState, useEffect, useRef } from 'react';
import { Image } from '@tarojs/components'
import {isvStorage, util} from "@conecli/cone-render/api";
import styles from './index.module.scss';

const FollowShopPopup = ({ onClose}) => {
  const lzUtils = isvStorage.getItem('lzUtilsShowcase');
  const header = isvStorage.getItem('headerShowcase');

  // 关注店铺
  const followShopClick = async () => {
    try {
      await lzUtils.postUrl('/10119/followShop', {}, header);
      util.showSuccessToast({
        title: '关注成功',
        duration: 3000
      })
    } catch (error) {
      util.showFailToast({
        title: error.message,
        duration: 3000
      })
    }
  };

  return (
    <div className={styles['FollowShopPopup']} onClick={(e) => {
      e.stopPropagation();
    }}>
      <div className={styles['rule-bk']}>
        <Image
          src="//img10.360buyimg.com/imgzone/jfs/t1/280484/33/17243/918/67f72edfF8b7f296b/989835f01adf2c9f.png"
          alt=""
          className={styles['close']}
          onClick={onClose}
        />
        <div className={styles['title']}>抱歉，您还未关注当前店铺</div>
        <div className={styles['followShop']} onClick={followShopClick}>关注店铺</div>
      </div>
    </div>
  );
};

export default FollowShopPopup;
