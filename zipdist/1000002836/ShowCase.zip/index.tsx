import React, { useState, useEffect, useRef } from 'react';
import Taro from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import {isvStorage, shopMember, util} from '@conecli/cone-render/api'
import SkuDetailPopup from './components/SkuDetailPopup/index';
import BagPopup from './components/BagPopup/index';
import CouponsPopup from './components/CouponsPopup/index';
import RecommondPopup from './components/RecommondPopup/index';
import OpenCardPopup from './components/OpenCardPopup/index';
import FollowShopPopup from './components/FollowShopPopup/index';
import style from './index.module.scss';
import ShowcaseUtils from "./utils";

const initFurnish = {
  actBg: '//img10.360buyimg.com/imgzone/jfs/t1/326309/5/17957/726657/68bfc43fF7ed4c7ef/603f98b48c4022e7.png',
  actWindowBg: '//img10.360buyimg.com/imgzone/jfs/t1/328297/14/23182/530091/68d36d3fF0bd2785b/21bfa60771d69ce5.png',
  actWindowTitleBg: '//img10.360buyimg.com/imgzone/jfs/t1/238439/2/30372/54815/68d36cdfF0596d01a/bf5f2d1ca5e9fa7a.png',
  couponBg: '//img10.360buyimg.com/imgzone/jfs/t1/336786/24/11920/7071/68ca7b91F16e252cf/9caaa1dc20430f93.png',
  skuCardImg: '//img10.360buyimg.com/imgzone/jfs/t1/344509/9/1332/22688/68bfbe34F6c149c7a/e0015227e26d04bc.png',
  bagImg1: '//img10.360buyimg.com/imgzone/jfs/t1/332959/32/13888/49221/68c90c61Fa60a0e89/0d0a6d40d902c5cd.png',
  bagImg2: '//img10.360buyimg.com/imgzone/jfs/t1/326984/26/18036/48267/68bfbe3fF75c6a816/16b2efeba896c227.png',
  bagImg3: '//img10.360buyimg.com/imgzone/jfs/t1/225277/7/38929/51240/68ca675cFf46712c2/2f29b9eea39dca98.png',
  getBtnBg: '//img10.360buyimg.com/imgzone/jfs/t1/329463/18/10864/14439/68bfc51dFd4805537/f2b06c7955e47bb0.png',
  moreBg: '//img10.360buyimg.com/imgzone/jfs/t1/342219/25/1319/10659/68bfbe3aF36794210/10972932003808c0.png',
  more2Bg: '//img10.360buyimg.com/imgzone/jfs/t1/338016/11/8674/10788/68bfbe3aF68e761b3/72b2843042e51172.png',
  titleColor: '#F82B2B',
  skuTitleColor: '#fff',
  titleText: '领券加购·组合优惠更划算',
  showPrice: true,
}

let topShelfProducts1:any = [];
let bottomShelfProducts1:any = [];

const ShowCase = ({floorData}) => {
  // 使用 useRef 来追踪初始化状态，确保初始化逻辑只执行一次
  const isInit = React.useRef(false);
  // lzUtils 状态用于存储 ShowcaseUtils 类的实例
  const [lzUtils, setLzUtils] = React.useState<any>(null);
  const [header, setHeader] = React.useState<any>({});
  const [furnish, setFurnish]= React.useState<any>(initFurnish);

  useEffect(() => {
    if (!isInit.current) {
      let utils = isvStorage.getItem('showcase_instance');
      if (!utils) {
        utils = ShowcaseUtils.getInstance();
      }
      if (!utils.isInitialized) {
        utils.init().then(() => {
          setLzUtils(utils);
          isInit.current = true;
        });
      } else {
        setLzUtils(utils);
        isInit.current = true;
      }
    }
  }, []);

  const [activityInfo, setActivityInfo] = useState<any>({
    products: [],
    orderingSku: 0,
    listCouponFlag: 0,
    windowCouponFlag: 0,
  });
  const [couponInfo, setCouponInfo] = useState<any>({
    windowsCouponsStatus: 0,
    windowCouponList: [],
  })
  const [recommondList, setRecommondList] = useState<any>([]);
  const [showModule, setShowModule] = useState(false);


  const getDecorationActivityConfig = async (header) => {
    try {
      const {data} = await lzUtils.httpRequest('/10119/getDecorationActivityConfig', {
        keyName: 'showcase'
      }, header);
      // setShowModule(true)
      setShowModule((data || data == 0) ? true : false)
      console.log('getDecorationActivityConfig', data)
    } catch (error) {
      if (error?.message) {
        util.showFailToast({
          title: error?.message,
          duration: 3000
        })
      }
    }
  };

  const getCouponList = async (header) => {
    try {
      const {data: couponList} = await lzUtils.postUrl('/10119/getCouponList', {}, header);
      const windowCouponList = couponList.windowsCoupons.map((item: any) => ({
        ...item,
        stair: item.stair ? JSON.parse(item.stair) : [],
      }));
      setCouponInfo({
        windowsCouponsStatus: couponList.status,
        windowCouponList,
      })
    } catch (error) {
      if (error?.message) {
        util.showFailToast({
          title: error?.message,
          duration: 3000
        })
      }
    }
  };

  const getActivityInfo = async (header) => {
    try {
      const {data: activity} = await lzUtils.postUrl('/10119/activity', {}, header);
      const {data: products} = await lzUtils.postUrl('/10119/getSkuList', {}, header);
      setActivityInfo({
        orderingSku: activity.orderingSku,
        listCouponFlag: activity.listCouponFlag,
        windowCouponFlag: activity.windowCouponFlag,
        products,
        startTime: activity.startTime,
        endTime: activity.endTime,
      })
    } catch (error) {
      if (error?.message) {
        util.showFailToast({
          title: error?.message,
          duration: 3000
        })
      }
    }
  };
  const getOrderingSkuList = async (header) => {
    try {
      const {data} = await lzUtils.postUrl('/10119/getOrderingSkuList', {}, header);
      setRecommondList(data);
    } catch (error) {
      if (error?.message) {
        util.showFailToast({
          title: error?.message,
          duration: 3000
        })
      }
    }
  };

  const fetchData = async (): Promise<void> => {
    if (lzUtils?.isInitialized) {
      isvStorage.setItem('lzUtilsShowcase', lzUtils)
      try {
        const {data: memberConfig}: any = await lzUtils.httpRequest('/common/getMemberConfig', {
          keyName: 'showcase',
        });
        const copyFurnish = furnish;
        const decoData = JSON.parse(memberConfig.memberRenovationData);
        Object.keys(decoData).forEach((item) => {
          copyFurnish[item] = decoData[item];
        });
        setFurnish(copyFurnish)
        const {data: loginData}: any = await lzUtils.httpRequest('/common/login', {
          activityId: JSON.parse(memberConfig.memberRenovationData).activityInfo.id,
        });

        const headerCopy = {};
        headerCopy['Pin-Token'] = loginData.loginResponse.pinToken;
        headerCopy['Activity-Id'] = JSON.parse(memberConfig.memberRenovationData).activityInfo.id;
        headerCopy['Activity-Type'] = '10119';
        headerCopy['Prd'] = 'crm';

        setHeader(headerCopy)
        isvStorage.setItem('headerShowcase', headerCopy);

        await getDecorationActivityConfig(headerCopy);
        await getActivityInfo(headerCopy);
        await getCouponList(headerCopy);
        await getOrderingSkuList(headerCopy);
      } catch (error) {
        if (error?.message) {
          util.showFailToast({
            title: error?.message,
            duration: 3000
          })
        }
      }
    }
  }

  useEffect(() => {
    fetchData().then();
  }, [lzUtils?.isInitialized]);


  // 状态定义
  const [showLimit, setShowLimit] = useState(false);
  const [isPaused, setIsPaused] = React.useState(false);
  const [topShelfProducts, setTopShelfProducts] = useState<Array<any>>([]);
  const [bottomShelfProducts, setBottomShelfProducts] = useState<Array<any>>([]);
  const shelfWidth = 13.5;
  const productWidth = 2.9; // 商品宽度
  const spacing = 1; // 商品间距
  const speed = 0.03; // 移动速度


  // 复制元素状态
  const [copiedProduct, setCopiedProduct] = useState<{
    show: boolean;
    name: string;
    style: React.CSSProperties;
  }>({
    show: false,
    name: '',
    style: {
      opacity: 0,
      position: 'absolute',
      left: '0px',
      top: '0px',
      width: '2.9rem',
      height: '3.4rem',
      zIndex: 100,
    },
  });

  const [currentSku, setCurrentSku] = useState<any>({});
  const [bagList, setBagList] = useState<any>([]);
  const [addPicShow, setAddPicShow] = useState(false);

  const animationIntervalId = useRef<any>(null);
  const shelfContainerRef = useRef<any>(null);
  const copiedProductRef = useRef<any>(null);
  const bagRef = useRef<any>(null);

  const useThreshold = (props: any): boolean => {
    const { thresholdList } = props;
    // 通用门槛
    const commonWarnList: any = thresholdList?.filter((e: any): boolean => !e.type);
    const commonWarnLength: number = commonWarnList?.length;

    // 自定义门槛
    const thresholdWarnList: any = thresholdList?.filter((e: any): boolean => !!e.type);
    const thresholdWarnLength: number = thresholdWarnList?.length;

    if (commonWarnLength) {
      const warnMessage: any = thresholdList[0];
      util.openDialog({
        title: warnMessage.thresholdTitle,
        message: warnMessage.thresholdContent,
      })
      return false;
    }
    return !!(!commonWarnLength && thresholdWarnLength);
  };
  // 校验条件
  const checkOutCondition = async () => {
    try {
      const {data} = await lzUtils.postUrl('/10119/thresholdVerification', {}, header);
      if (data.code === 1) {
        const thresholdList = [{
          thresholdTitle: '活动暂未开始',
          thresholdContent: `活动开始时间：${activityInfo.startTime}`,
        }];
        setShowLimit(useThreshold({
          thresholdList,
        }))
        return false;
      }
      if (data.code === 2) {
        const thresholdList = [{
          thresholdTitle: '抱歉，活动已结束',
          thresholdContent: '敬请关注其他活动',
        }];
        setShowLimit(useThreshold({
          thresholdList,
        }))
        return false;
      }
      if (data.code === 3) {
        const thresholdList = [{
          thresholdTitle: '抱歉，您未满足参与条件哦',
          thresholdContent: `原因为：${data.message}`, // 原因为：非参与指定人群
        }];
        setShowLimit(useThreshold({
          thresholdList,
        }))
        return false;
      }
      if (data.code === 4) {
        util.openDialog({
          className: style['OpenCardPopup'],
          maskCloseable: false,
          isCustom: true,
          hasFooter: false,
          bodyNode: <OpenCardPopup onClose={closePopup}></OpenCardPopup>,
        })
        return false;
      }
      if (data.code === 5) {
        util.openDialog({
          className: style['OpenCardPopup'],
          maskCloseable: false,
          isCustom: true,
          hasFooter: false,
          bodyNode: <FollowShopPopup onClose={closePopup}></FollowShopPopup>,
        })
        return false;
      }
      if (data.code === 10) {
        const thresholdList = [{
          thresholdTitle: '本次优惠券已领完',
          thresholdContent: '感谢您的关注!',
        }];
        setShowLimit(useThreshold({
          thresholdList,
        }))
        return false;
      }
      if (data.code === 0) {
        return true;
      }
      return false;
    } catch (error: any) {
      if (error?.message) {
        util.showFailToast({
          title: error?.message,
          duration: 3000
        })
      }
      return false;
    }
  };

  // 关弹窗
  const closePopup = () => {
    // setCopiedProduct(prev => ({ ...prev, show: false }));
    util.closeDialog()
  };

  // 加购商品
  const addSkuCart = async (skuIds: any, type: number) => {
    try {
      await lzUtils.postUrl('/10119/addSku', {
        skuInfo: {
          skuIds,
          type,
        },
      }, header);
      util.showSuccessToast({
        title: '加购成功',
        duration: 3000
      })
    } catch (error: any) {
      if (error?.message) {
        util.showFailToast({
          title: error?.message,
          duration: 3000
        })
      }
    }
  };

  // 弹窗
  const showBag = () => {
    util.openDialog({
      className: style['BagPopup'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <BagPopup
        bagList={bagList}
        onClose={closePopup}
        onClickBtn={clickBtn}
        onDelSku={delSku}
        onSelectSku={selectSku}
        onAddCart={addSkuCart}
      />,
    })
  };
  const clickBtn = (fromType) => {
    util.openDialog({
      className: style['CouponsPopup'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <CouponsPopup
        activityInfo={activityInfo}
        fromType={fromType}
        onClose={closePopup}
        onBackSSD={backSSD}
        onToTJZH={toTJZH}
        onCheckOutCondition={checkOutCondition}
      />,
    })
  };
  const backSSD = () => {
    util.openDialog({
      className: style['BagPopup'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <BagPopup
        bagList={bagList}
        onClose={closePopup}
        onClickBtn={clickBtn}
        onDelSku={delSku}
        onSelectSku={selectSku}
        onAddCart={addSkuCart}
      />,
    })
  };
  const toTJZH = () => {
    util.openDialog({
      className: style['RecommondPopup'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <RecommondPopup
        recommondList={recommondList}
        onClose={closePopup}
        onToLJLJ={toLJLJ}
        onAddCart={addSkuCart}
      />,
    })
  };
  const toLJLJ = (fromType) => {
    util.openDialog({
      className: style['CouponsPopup'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <CouponsPopup
        activityInfo={activityInfo}
        fromType={fromType}
        onClose={closePopup}
        onBackSSD={backSSD}
        onToTJZH={toTJZH}
        onCheckOutCondition={checkOutCondition}
      />,
    })
  };

  // 购物袋商品
  const delSku = (skuId) => {
    setBagList(prev => prev.filter((item:any) => item.skuId !== skuId));
  };
  const selectSku = (skuId) => {
    const copBagList = bagList.map((item:any)=> {
      if (item.skuId === skuId) {
        return { ...item, select: !item.select };
      }
      return item;
    })
    setBagList(copBagList);
  };

  // 初始化货架商品
  const initShelves = () => {
    // 生成商品假数据
    const productCount = activityInfo.products.length;
    const newProducts = activityInfo.products.map((item: any, i) => ({
      ...item,
      opacity: 1,
      select: false,
      name: `${i + 1}`,
    }));

    // 空数据，6,7和8有问题，补充两个空的商品块，用于占位
    const jsj0 = [
      {
        name: 'block_empty',
        skuId: '10697731c',
        skuMainPicture: '',
        skuName: '',
        select: false,
        opacity: 0,
        jdPrice: '0.00',  // 添加
        cxPrice: '0.00',  // 添加
      }, {
        name: 'block_empty',
        skuId: '10695732d',
        skuMainPicture: '',
        skuName: '',
        select: false,
        opacity: 0,
        jdPrice: '0.00',  // 添加
        cxPrice: '0.00',  // 添加
      },
      {
        name: 'block_empty',
        skuId: '10697731e',
        skuMainPicture: '',
        skuName: '',
        select: false,
        opacity: 0,
        jdPrice: '0.00',  // 添加
        cxPrice: '0.00',  // 添加
      },
    ];
    const jsj1 = [
      {
        name: 'block_empty',
        skuId: '10697731c',
        skuMainPicture: '',
        skuName: '',
        select: false,
        opacity: 0,
        jdPrice: '0.00',  // 添加
        cxPrice: '0.00',  // 添加
      }, {
        name: 'block_empty',
        skuId: '10695732d',
        skuMainPicture: '',
        skuName: '',
        select: false,
        opacity: 0,
        jdPrice: '0.00',  // 添加
        cxPrice: '0.00',  // 添加
      },
    ];
    const jsj2 = [
      {
        name: 'block_empty',
        skuId: '10697731c',
        skuMainPicture: '',
        skuName: '',
        select: false,
        opacity: 0,
        jdPrice: '0.00',  // 添加
        cxPrice: '0.00',  // 添加
      },
    ];

    if (productCount == 6) {
      newProducts.push(...jsj0);
    }
    if (productCount == 7) {
      newProducts.push(...jsj1);
    } else if (productCount == 8) {
      newProducts.push(...jsj2);
    }

    // 初始化货架商品
    if (productCount > 0) {
      let topCount;
      if (productCount > 8) {
        topCount = Math.floor(productCount / 2);
      } else if (productCount > 4 && productCount <= 8) {
        topCount = 4;
      } else {
        topCount = productCount;
      }

      let currentPosition = 0;
      const topShelf:any = [];
      for (let i = 0; i < topCount; i++) {
        topShelf.push({
          ...newProducts[i],
          position: currentPosition,
        });
        currentPosition += (productWidth + spacing);
      }
      setTopShelfProducts(topShelf);
      topShelfProducts1 = [...topShelf]

      const bottomCount = (productCount === 6 || productCount === 7 || productCount === 8) ? 9 : productCount;
      let currentPositionBottom = shelfWidth;
      const bottomShelf:any = [];
      for (let i = topCount; i < bottomCount; i++) {
        bottomShelf.push({
          ...newProducts[i],
          position: currentPositionBottom,
        });
        currentPositionBottom -= (productWidth + spacing);
      }
      setBottomShelfProducts(bottomShelf);
    }
  };

  // 更新上层商品位置
  const updateTopShelf = () => {
    setTopShelfProducts(prev =>
      prev.map(product => ({
        ...product,
        position: product.position + speed,
      }))
    );
    topShelfProducts1 = topShelfProducts1.map(product => ({
      ...product,
      position: product.position + speed,
    }))

    // 更新下层商品位置
  };

  // 更新下层商品位置
  const updateBottomShelf = () => {
    setBottomShelfProducts(prev =>
      prev.map(product => ({
        ...product,
        position: product.position - speed,
      }))
    );
    bottomShelfProducts1 = bottomShelfProducts1.map(product => ({
      ...product,
      position: product.position - speed,
    }))
  };

  // 处理商品转移
  const handleProductTransfer = () => {
    // 检查上层需要转移到下层的商品
    const transferToBottom = topShelfProducts1.filter(
      (product) => product.position >= shelfWidth,
    );

    // 检查下层需要转移到上层的商品
    const transferToTop = bottomShelfProducts1.filter(
      (product) => product.position <= -productWidth,
    );

    // 从上层移除需要转移的商品
    if (transferToBottom.length > 0) {
      setTopShelfProducts(prev =>
        prev.filter(product => product.position < shelfWidth)
      );
      topShelfProducts1 = topShelfProducts1.filter(product => product.position < shelfWidth)
    }

    // 从下层移除需要转移的商品
    if (transferToTop.length > 0) {
      setBottomShelfProducts(prev =>
        prev.filter(product => product.position > -productWidth)
      );
      bottomShelfProducts1 = bottomShelfProducts1.filter(product => product.position > -productWidth)
    }

    // 添加转移到下层的商品
    if (transferToBottom.length > 0) {
      setBottomShelfProducts(prev => {
        const newProducts = [...prev];
        transferToBottom.forEach((product) => {
          let rightmostPosition = shelfWidth;
          if (newProducts.length > 0) {
            rightmostPosition = Math.max(...newProducts.map((p) => p.position));
          }
          const newPosition = rightmostPosition + (productWidth + spacing);
          newProducts.push({
            ...product,
            position: newPosition,
          });
        });
        bottomShelfProducts1 = [...newProducts]
        return newProducts;
      });
    }

    // 添加转移到上层的商品
    if (transferToTop.length > 0) {
      setTopShelfProducts(prev => {
        const newProducts = [...prev];
        transferToTop.reverse().forEach((product) => {
          let leftmostPosition = -productWidth;
          if (newProducts.length > 0) {
            leftmostPosition = Math.min(...newProducts.map((p) => p.position));
          }
          const newPosition = leftmostPosition - (productWidth + spacing);
          newProducts.push({
            ...product,
            position: newPosition,
          });
        });
        topShelfProducts1 = [...newProducts]
        return newProducts;
      });
    }
  };

  // 调整商品间距
  const adjustSpacing = () => {
    // 调整上层商品间距
    if (topShelfProducts.length > 1) {
      const sortedTop = [...topShelfProducts].sort((a, b) => a.position - b.position);
      for (let i = 1; i < sortedTop.length; i++) {
        const prevProduct = sortedTop[i - 1];
        const currentProduct = sortedTop[i];
        const requiredPosition = prevProduct.position + productWidth + spacing;

        if (currentProduct.position < requiredPosition) {
          sortedTop[i] = { ...currentProduct, position: requiredPosition };
        }
      }
      setTopShelfProducts(sortedTop);
    }

    // 调整下层商品间距
    if (bottomShelfProducts.length > 1) {
      const sortedBottom = [...bottomShelfProducts].sort((a, b) => b.position - a.position);
      for (let i = 1; i < sortedBottom.length; i++) {
        const prevProduct = sortedBottom[i - 1];
        const currentProduct = sortedBottom[i];
        const requiredPosition = prevProduct.position - productWidth - spacing;

        if (currentProduct.position > requiredPosition) {
          sortedBottom[i] = { ...currentProduct, position: requiredPosition };
        }
      }
      setBottomShelfProducts(sortedBottom);
    }
  };

  // 滚动动画
  const updatePositions = () => {
    handleProductTransfer();
    updateTopShelf();
    updateBottomShelf();
    adjustSpacing();
  };

  // 使用 setInterval 替代 requestAnimationFrame
  const startAnimation = () => {
    if (animationIntervalId.current) return; // 防止重复启动
    animationIntervalId.current = setInterval(() => {
      if (!isPaused) {
        updatePositions();
      }
    }, 1000/60); // 约 60 FPS
  };

  const stopAnimation = () => {
    if (animationIntervalId.current) {
      clearInterval(animationIntervalId.current);
      animationIntervalId.current = null;
    }
  };

  const state = useRef(true);

  // 领取优惠券
  const getCoupon = async (couponIds: [], type) => {
    // 防止连点
    if (!state.current) return;
    state.current = false;
    const result = await checkOutCondition();
    if (!result) {
      state.current = true;
      return;
    }
    try {
      const {data} = await lzUtils.postUrl('/10119/receiveCoupon', {
        couponIds,
        type,
      }, header);
      if (data.code === 0) {
        await getCouponList(header)
        util.showSuccessToast({
          title: '领取成功',
          duration: 3000
        })
      } else {
        util.showFailToast({
          title: data.message,
          duration: 3000
        })
      }
    } catch (error: any) {
      if (error?.message) {
        util.showFailToast({
          title: error.message,
          duration: 3000
        })
      }
    } finally {
      state.current = true;
    }
  };
  const clickCoupon = async () => {
    const couponIds = couponInfo.windowCouponList.map((x: { id: any; }) => x.id);
    getCoupon(couponIds, 0);
  };

  // 点击商品
  const handleProduct = (product, index, event, shelfType) => {
    event.stopPropagation();
    if (bagList.some((x) => x.skuId === product.skuId)) {
      util.showFailToast({
        title: '该商品已添加，看看其他好物~',
        duration: 3000
      })
      return;
    }

    util.openDialog({
      className: style['SkuDetailPopup'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <SkuDetailPopup
        currentSku={product}
        currentIndex={index}
        currentShelf={shelfType}
        onClose={closePopup}
        onAddBagNow={addBag}
        floorData={floorData}
      />,
    })
    setCurrentSku(product);

    const clickedElement = event.currentTarget;
    const rect = clickedElement.getBoundingClientRect();

    setCopiedProduct({
      show: true,
      name: product.name,
      style: {
        opacity: 0,
        position: 'absolute',
        left: `${rect.left}px`,
        top: `${rect.top}px`,
        width: `${rect.width}px`,
        height: `${rect.height}px`,
        zIndex: 100,
      },
    });

    setIsPaused(prev => !prev);
  };

  const addBag = (currentSku, currentIndex, currentShelf) => {
    closePopup();

    // 原来位置的商品opacity设置为0
    if (currentShelf === 'top') {
      setTopShelfProducts(prev =>
        prev.map((product, index) => {
          if (product.name !== 'block') product.opacity = 1;
          if (index === currentIndex) {
            return { ...product, opacity: 0 };
          }
          return product;
        })
      );
    } else if (currentShelf === 'bottom') {
      setBottomShelfProducts(prev =>
        prev.map((product, index) => {
          if (product.name !== 'block') product.opacity = 1;
          if (index === currentIndex) {
            return { ...product, opacity: 0 };
          }
          return product;
        })
      );
    }

    if (!copiedProductRef.current || !bagRef.current) return;
    const endRect = bagRef.current?.getBoundingClientRect();
    const startRect = copiedProductRef.current?.getBoundingClientRect()

    const startPos = {
      top: Number(copiedProductRef.current?.style.top.replace('px', '')),
      left: Number(copiedProductRef.current?.style.left.replace('px', '')),
      width: Number(copiedProductRef.current?.style.width.replace('px', '')),
      height: Number(copiedProductRef.current?.style.height.replace('px', '')),
    };

    const endPos = {
      top: endRect.top + (endRect.height / 2) - (startRect.height / 4) - 55,
      left: endRect.left + (endRect.width / 2) - (startRect.width / 4) - 15,
      width: startRect.width / 1,
      height: startRect.height / 1,
    };

    setCopiedProduct(prev => ({
      ...prev,
      style: {
        ...prev.style,
        opacity: 1,
        position: 'fixed',
        left: `${startPos.left}px`,
        top: `${startPos.top}px`,
        width: `${startPos.width}px`,
        height: `${startPos.height}px`,
        transform: 'rotate(-30deg)',
      },
    }));

    const duration = 500;
    const startTime = Date.now();

    const easeOutQuad = (t) => t * (2 - t);

    // 使用 setInterval 替代 requestAnimationFrame
    const intervalId = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = easeOutQuad(progress);

      const currentLeft = startPos.left + (endPos.left - startPos.left) * easeProgress;
      const currentTop = startPos.top + (endPos.top - startPos.top) * easeProgress;
      const currentWidth = startPos.width + (endPos.width - startPos.width) * easeProgress;
      const currentHeight = startPos.height + (endPos.height - startPos.height) * easeProgress;
      const rotation = -30 + (0 - (-30)) * easeProgress;

      setCopiedProduct(prev => ({
        ...prev,
        style: {
          ...prev.style,
          position: 'fixed',
          left: `${currentLeft}px`,
          top: `${currentTop}px`,
          width: `${currentWidth}px`,
          height: `${currentHeight}px`,
          transform: `rotate(${rotation}deg)`,
        },
      }));

      setIsPaused(prev => !prev);

      if (progress >= 1) {
        clearInterval(intervalId);
        setTimeout(() => {
          setCopiedProduct(prev => ({ ...prev, show: false }));

          if (currentShelf === 'top') {
            setTopShelfProducts(prev =>
              prev.map(product => ({ ...product, opacity: product.name !== 'block_empty' ? 1 : product.opacity  }))
            );
          } else if (currentShelf === 'bottom') {
            setBottomShelfProducts(prev =>
              prev.map(product => ({ ...product, opacity: product.name !== 'block_empty' ? 1 : product.opacity }))
            );
          }

          setBagList(prev => [...prev, currentSku]);
          setAddPicShow(true);

          setTimeout(() => {
            setAddPicShow(false);
            setIsPaused(false);
          }, 500);
        }, 10);
      }
    }, 1000 / 60); // 约 60 FPS
  };

  useEffect(() => {
    if(activityInfo.products.length > 0){
      initShelves();
      startAnimation();
    }

    return () => {
      stopAnimation();
    };
  }, [activityInfo]);

  return (
    <View>
      {
        showModule && <View className={style['CombinationLottery']}>
          {/* 标题 */}
          <div className={style['CombinationLottery-title']} style={{
            backgroundImage: `url(${furnish.actWindowTitleBg})`,
          }}>{ furnish.titleText }</div>
          <View className={style['CombinationLottery-bg']} style={{ backgroundImage: `url(${furnish.actWindowBg})` }}>
            {/* 优惠券 */}
            {
              activityInfo.windowCouponFlag != 0 && (
                <View className={style['coupons']}>
                  <View className={style['coupons-all']}>
                    {couponInfo.windowCouponList?.map((item, index) => (
                      <View
                        key={index}
                        className={style['coupons-item']}
                        style={{ backgroundImage: `url(${furnish.couponBg})` }}
                      >
                        {item.discountType === 1 ? (
                          <View className={style['coupons-money']}>
                            <span style={{ fontSize: '0.3rem', fontWeight: 'bold' }}>￥</span>
                            {item.couponDiscount}
                          </View>
                        ) : item.discountType === 2 && item.stair ? (
                          <View className={style['coupons-money']}>
                            {item.stair[item.stair.length - 1].discount}
                            <span style={{ fontSize: '0.3rem', fontWeight: 'bold' }}>折</span>
                          </View>
                        ) : null}

                        <View className={style['coupons-right']}>
                          <View className={style['coupons-range']}>
                            {item.rangeType === 1 ? '全店商品' : '部分商品'}
                          </View>
                          <View className={style['coupons-couponQuota']}>
                            满{item.discountType === 1 ? item.couponQuota : item.stair ? item.stair[item.stair.length - 1].quota : '-'}可用
                          </View>
                        </View>
                      </View>
                    ))}
                  </View>
                  <Image
                    className={`${couponInfo.windowsCouponsStatus === 1 ? style['coupons-get-disabled'] : ''} ${style['coupons-get']}`}
                    onClick={clickCoupon}
                    src={furnish.getBtnBg}
                  />
                </View>
              )
            }
            

            <Image
              className={style['glass']}
              src="//img10.360buyimg.com/imgzone/jfs/t1/287351/10/24848/52764/68ca7a26Ffd10418b/b170ecce25b8719f.png"
            />

            {/* 两层货架 */}
            <View className={style['lottery']}>
              <View className={style['shelf-container']} ref={shelfContainerRef}>
                {/* 上层货架 */}
                <View className={style['shelf-top']}>
                  <View className={style['shelf-track']}>
                    {topShelfProducts.map((product:any, index) => (
                      <View
                        key={`top-${product.skuId}`}
                        className={style['product-item']}
                        style={{
                          transform: `translateX(${product.position}rem)`,
                          opacity: product.opacity,
                        }}
                        onClick={(e) => {
                          handleProduct(product, index, e, 'top')
                        }}
                      >
                        <Image className={style['product-image']} src={product.skuMainPicture}  />
                        {
                          furnish.showPrice && <View className={style['product-content']}>￥ {product.jdPrice}</View>
                        }
                        
                      </View>
                    ))}
                  </View>
                </View>

                {/* 下层货架 */}
                <View className={style['shelf-bottom']}>
                  <View className={style['shelf-track']}>
                    {bottomShelfProducts.map((product:any, index) => (
                      <View
                        key={`bottom-${product.skuId}`}
                        className={style['product-item']}
                        style={{
                          transform: `translateX(${product.position}rem)`,
                          opacity: product.opacity,
                        }}
                        onClick={(e) => {
                          handleProduct(product, index, e, 'bottom')
                        }}
                      >
                        <Image className={style['product-image']} src={product.skuMainPicture}  />
                        {
                          furnish.showPrice && <View className={style['product-content']}>￥ {product.jdPrice}</View>
                        }
                      </View>
                    ))}
                  </View>
                </View>
              </View>

              {/* 复制元素 */}
              {copiedProduct.show && (
                <View
                  ref={copiedProductRef}
                  className={`${style['product-item']} ${style['copied-product']}`}
                  style={copiedProduct.style}
                >
                  <Image className={style['product-image']} src={currentSku.skuMainPicture}  />
                  <View className={style['product-content']}>￥ {currentSku.jdPrice}</View>
                </View>
              )}
            </View>

            {/* 省钱袋 */}
            {/*<View className={style['bagPos']} style={{ left: '8.4rem', top: '13.5rem' }}></View>*/}
            <View ref={bagRef} className={style['bag']} style={{ left: '6.5rem', top: '13.1rem' }}>
              {bagList.length === 0 ? (
                <Image className={`${style['bag-img']} ${style['img1']}`} src={furnish.bagImg1} />
              ) : (
                <Image className={`${style['bag-img']} ${style['img2']}`} src={furnish.bagImg2}  />
              )}
              {addPicShow && (
                <Image className={`${style['bag-img']} ${style['img3']}`} src={furnish.bagImg3}  />
              )}
            </View>
            {
              bagList.length > 0 && (
                <View className={style['bag-num']}>{bagList.length}</View>
              )
            }

            {/* +1 */}
            {addPicShow && (
              <Image
                className={style['add-pic']}
                src="//img10.360buyimg.com/imgzone/jfs/t1/342939/38/1322/4582/68bfbe3eF64a84360/e666dec685fbd8c2.png"
              />
            )}

            {/* 查看商品 */}
            {bagList.length > 0 && (
              <Image
                className={style['bag-btn']}
                onClick={showBag}
                src="//img10.360buyimg.com/imgzone/jfs/t1/324541/5/17919/28661/68bfbe3bFe7827095/232d63853c68cf2b.png"
              />
            )}

            {/* 更多优惠 */}
            {activityInfo.listCouponFlag != 0 && 
              <Image
                className={style['moreBg']}
                src={furnish.moreBg ?? ''}
                onClick={() => clickBtn(1)}
              />
            }
            
            {/* 推荐组合 */}
            {activityInfo.orderingSku == 1 && (
              <Image
                className={style['more2Bg']}
                src={furnish.more2Bg ?? ''}
                onClick={() => {
                  util.openDialog({
                    className: style['RecommondPopup'],
                    maskCloseable: false,
                    isCustom: true,
                    hasFooter: false,
                    bodyNode: <RecommondPopup
                      recommondList={recommondList}
                      onClose={closePopup}
                      onToLJLJ={toLJLJ}
                      onAddCart={addSkuCart}
                    />,
                  })
                }}
              />
            )}
          </View>
        </View>
      }
    </View>
  );
};

export default ShowCase;
