import React from 'react'
import { Text, View, MovableArea, MovableView } from '@tarojs/components'
import {isvStorage, moduleUtil, util, http, jump, track, global} from '@conecli/cone-render/api'
import { CountDown } from '@conecli/cone-render/components';
import styles from './index.module.scss'
import useInit from "./useInit";
import { set } from 'lodash';

const lineImg = '//img10.360buyimg.com/imgzone/jfs/t1/296595/35/1600/2091/68119bafF8166daf5/f0a940226862bc55.png'

const StepsGift = (props) => {
  const { floorData } = props
  const lzUtils = useInit();
  const [init, setInit] = React.useState(false);
  const [showModal, setShowModal] = React.useState(true);
  // { // 下单阶梯礼配置
  //   orderBtnImage: string, // 下单按钮背景图
  //   coverImage: string, // 背景图
  //   subIcon: string, // 左上角角标
  //   prizeAmountIcon: string, // 奖品图头部满x元图标
  //   activityInfo: object, // 活动信息
  //   crowdRules: object, // 人群规则
  // }
  const [decorateData, setDecorateData] = React.useState<any>({});
  const [list, setList] = React.useState([{
    stepAmount: 0,
    prizeImg: '',
    prizeName: '',
    remainCount: 0,
    stepOrderNum: 0,
  }]);  // 等级列表
  const [activityInfo, setActivityInfo] = React.useState({
    startTime: '',
    endTime: '',
    priceDifference: '', // 距下一阶梯还差多少钱
    orderDifference: '', // 距下一阶梯还差多少单
    conditionType: 0, // 下单条件
    moneyConditionType: 0, // 金额条件
  });

  const fetchData = async () => {
    if (lzUtils?.isInitialized) {
      try {
        const {data: memberConfig} = await lzUtils.httpRequest('/10096/getDecorationActivityConfig', {
          keyName: 'stairs',
        });
        if (memberConfig.memberRenovationData) {
          const result = JSON.parse(memberConfig.memberRenovationData);
          setDecorateData({
            ...result,
            orderBtnImage: result.orderBtnImage || '//img10.360buyimg.com/imgzone/jfs/t1/291685/30/1615/72410/68119b8cF14163802/d443794fe91094ad.png', // 下单按钮背景图
            coverImage: result.coverImage || '//img10.360buyimg.com/imgzone/jfs/t1/288161/2/3342/28107/6819741cF8ee5cff3/b4dd3ff8d0e92d13.png', // 背景图
            subIcon: result.subIcon || '//img10.360buyimg.com/imgzone/jfs/t1/275709/22/28642/90428/68119b88F24c9e49e/4ac901fd1a041dd0.png', // 左上角角标
            prizeAmountIcon: result.prizeAmountIcon || '//img10.360buyimg.com/imgzone/jfs/t1/295654/24/1413/6252/68119bceFc19a53a1/946888c431e42ba7.png', // 奖品图头部满x元图标
          });
          const {data: loginData}: any = await lzUtils.httpRequest('/common/login', {
            activityId: result.activityInfo.id,
          });
          let header= {};
          header['Pin-Token'] = loginData.loginResponse.pinToken;
          header['Activity-Id'] = result.activityInfo.id;
          header['Activity-Type'] = '10096';
          header['Prd'] = 'crm';
          const getActivityInfo = await lzUtils.httpRequest('/10096/getDecorationActivity', {
            activityId: result.activityInfo.id,
          }, header);
          if(getActivityInfo.data) {
            setActivityInfo({
              ...activityInfo,
              ...getActivityInfo.data
            })
          }
          console.log('getActivityInfo:', getActivityInfo.data.endTime);
          if (getActivityInfo.data.endTime <= Date.now()) {
            setShowModal(false);
          }
          const getList = await lzUtils.httpRequest('/10096/getDecorationPrizeList', {
            activityId: result.activityInfo.id,
          }, header);
          if(getList.data) {
            setList(getList.data)
          }

          setInit(true);
        } else {
          setShowModal(false);
        }
      } catch (e) {
        // 出现异常不显示这个模块
        console.log(e)
        setShowModal(false);
      }
    }
  }
  // 立即下单-跳转链接
  const jumpLink = () => {
    const trackEventInfo = track.getIsvClickEventInfo(floorData)
    console.log('trackEventInfo:', trackEventInfo)
    jump.business.jdJumpConfigUrl({ configDataType: 22, configDataValue: { linkUrl: decorateData.orderBtnLink }}, trackEventInfo)
  }
  //当时间到达开始时间触发
  const _startTimeCallBack = (e: any) => {
    console.log('startTimeCallBack', e);
  };
//当时间到达结束时间触发
  const _endTimeCallBack = (e: any) => {
    console.log('endTimeCallBack', e);
  };
  const handleScroll = (e) => {
    e.stopPropagation(); // 阻止事件冒泡
  };
  React.useEffect(() => {
    fetchData();
  }, [lzUtils?.isInitialized]);

  // 开发模块效果
  if(!showModal) return null;

  return (
    <View className={styles.stepsGiftPreview}>
      {
        init && <View className={styles.stepsGift}
        style={
          {
            '--bg-img': `url(${decorateData.coverImage})`,
          } as any
        }
        >
          <img src={decorateData.subIcon} className={styles.subIcon} alt='' />
          <View className={styles.countDownContainer}>
            <CountDown
              className={styles.countDown}
              serverTime={Date.now()}
              endTime={activityInfo.endTime}
              startTime={activityInfo.startTime}
              startTitleText="距离活动开始还有:"
              endTitleText="距离活动结束还剩:"
              endTimeEndCallBack={(e) => _endTimeCallBack(e)}
              startTimeEndCallBack={(e) => _startTimeCallBack(e)}
              info={{
                data: '根据业务自定义参数，可在时间到达后在回调的e中返回',
                showMilliseconds: true
              }} // 传入的自定义数据
              showDaytimeNumSpaceTextState={true}// 有天的时候时间数字间隔类型是否为文字型 时分秒
              timeNumSpaceTextState={true} //时间数字间隔类型是否为文字型 时分秒 默认否 即是冒号
              showDayState={true} //是否仅仅展示天，不展示时分秒，当天大于0的时候触发
            />
          </View>
          {
            list.length === 1 && <View className={styles.activityInfoLower1}>
             {
              list.map((item, index) => {
                return (
                  <View className={styles.activityInfoItem} key={index}>
                      <img className={styles.activityInfoItemImg} src='//img10.360buyimg.com/imgzone/jfs/t1/317892/36/401/28665/68242e48F8b35ea93/26e4c3adc23b224c.png' alt='' />
                      <View
                        className={styles.topImg}
                        style={{backgroundImage: `url(${decorateData.prizeAmountIcon})`}}
                      >
                        {/* 满{item.stepAmount || 0}可领 */}
                        {
                          activityInfo?.conditionType === 1 ?
                            `满${item.stepOrderNum || 0}笔` :
                            activityInfo?.conditionType === 2 ?
                              `满${item.stepAmount || 0}元${item.stepOrderNum || 0}笔` :
                              `满${item.stepAmount || 0}元`
                        }
                      </View>
                      <img className={styles.prizeImg} src={item.prizeImg} alt='' />
                      <Text className={styles.activityInfoItemText}>{item.prizeName}</Text>
                      <Text className={styles.activityInfoItemTotal}>{`剩余${item.remainCount}份`}</Text>
                  </View>
                )
              })
            }
            </View>
          }
          {
            list.length === 2 && <View className={styles.activityInfoLower}>
              <View className={styles.activityInfoItem}>
                <img className={styles.activityInfoItemImg} src='//img10.360buyimg.com/imgzone/jfs/t1/290651/12/1048/40337/68119be6F139adc26/a37dc820bc14e222.png' alt='' />
                <View
                  className={styles.topImg}
                  style={{backgroundImage: `url(${decorateData.prizeAmountIcon})`}}
                >
                  {/* 满{list[0].stepAmount || 0}可领 */}
                  {
                    activityInfo?.conditionType === 1 ?
                      `满${list[0].stepOrderNum || 0}笔` :
                      activityInfo?.conditionType === 2 ?
                        `满${list[0].stepAmount || 0}元${list[0].stepOrderNum || 0}笔` :
                        `满${list[0].stepAmount || 0}元`
                  }
                </View>
                <img className={styles.prizeImg} src={list[0].prizeImg} alt='' />
                <Text className={styles.activityInfoItemText}>{list[0].prizeName}</Text>
                <Text className={styles.activityInfoItemTotal}>{`剩余${list[0].remainCount}份`}</Text>
              </View>
              <img className={styles.nextImg} src="//img10.360buyimg.com/imgzone/jfs/t1/292765/4/1143/9260/68119b6bF5ac13652/b15636743706388b.png" />
              <View className={styles.activityInfoItem}>
                <img className={styles.activityInfoItemImg} src='//img10.360buyimg.com/imgzone/jfs/t1/290651/12/1048/40337/68119be6F139adc26/a37dc820bc14e222.png' alt='' />
                <View
                  className={styles.topImg}
                  style={{backgroundImage: `url(${decorateData.prizeAmountIcon})`}}
                >
                  {/* 满{list[1].stepAmount || 0}可领 */}
                  {
                    activityInfo?.conditionType === 1 ?
                      `满${list[1].stepOrderNum || 0}笔` :
                      activityInfo?.conditionType === 2 ?
                        `满${list[1].stepAmount || 0}元${list[1].stepOrderNum || 0}笔` :
                        `满${list[1].stepAmount || 0}元`
                  }
                </View>
                <img className={styles.prizeImg} src={list[1].prizeImg} alt='' />
                <Text className={styles.activityInfoItemText}>{list[1].prizeName}</Text>
                <Text className={styles.activityInfoItemTotal}>{`剩余${list[1].remainCount}份`}</Text>
              </View>
            </View>
          }
          {
            list.length === 3 && <View className={styles.activityInfoUpper}>
            {
              list.map((item, index) => {
                return (
                  <>
                  <View className={styles.activityInfoItem} key={index}>
                    <img className={styles.activityInfoItemImg} src='//img10.360buyimg.com/imgzone/jfs/t1/286431/11/1321/30901/68119be6F455ca57f/c502a06eb61dbaf7.png' alt='' />
                    <View
                    className={styles.topImg}
                    style={{backgroundImage: `url(${decorateData.prizeAmountIcon})`}}
                    >
                      {/* 满{item.stepAmount || 0}可领 */}
                      {
                        activityInfo?.conditionType === 1 ?
                          `满${item.stepOrderNum || 0}笔` :
                          activityInfo?.conditionType === 2 ?
                            `满${item.stepAmount || 0}元${item.stepOrderNum || 0}笔` :
                            `满${item.stepAmount || 0}元`
                      }
                    </View>
                    <img className={styles.prizeImg} src={item.prizeImg} alt='' />
                    <Text className={styles.activityInfoItemText}>{item.prizeName}</Text>
                    <Text className={styles.activityInfoItemTotal}>{`剩余${item.remainCount}份`}</Text>
                  </View>
                  {
                    index < list.length - 1 && <img className={styles.nextImg} src="//img10.360buyimg.com/imgzone/jfs/t1/292765/4/1143/9260/68119b6bF5ac13652/b15636743706388b.png" />
                  }

                  </>
                )
              })
            }
            </View>
          }
          {
            list.length > 3 && <View className={styles.activityInfoUpper3}>
              <View className={styles.scrollXContainer} onTouchStart={handleScroll} onTouchMove={handleScroll}>
            {
              list.map((item, index) => {
                return (
                    <>
                    <View className={styles.activityInfoItem} key={index}>
                      <img className={styles.activityInfoItemImg} src='//img10.360buyimg.com/imgzone/jfs/t1/286431/11/1321/30901/68119be6F455ca57f/c502a06eb61dbaf7.png' alt='' />
                      <View
                      className={styles.topImg}
                      style={{backgroundImage: `url(${decorateData.prizeAmountIcon})`}}
                      >
                        {/* 满{item.stepAmount || 0}可领 */}
                        {
                          activityInfo?.conditionType === 1 ?
                            `满${item.stepOrderNum || 0}笔` :
                            activityInfo?.conditionType === 2 ?
                              `满${item.stepAmount || 0}元${item.stepOrderNum || 0}笔` :
                              `满${item.stepAmount || 0}元`
                        }
                      </View>
                      <img className={styles.prizeImg} src={item.prizeImg} alt='' />
                      <Text className={styles.activityInfoItemText}>{item.prizeName}</Text>
                      <Text className={styles.activityInfoItemTotal}>{`剩余${item.remainCount}份`}</Text>
                    </View>
                    {
                      index < list.length - 1 && <img className={styles.nextImg} src="//img10.360buyimg.com/imgzone/jfs/t1/292765/4/1143/9260/68119b6bF5ac13652/b15636743706388b.png" />
                    }
                  </>
                )
              })
            }
            </View>
            </View>
          }
          {/* 按钮 */}
          { list.length <= 2 &&
            <View className={styles.activityTwoBtns} >
              <View className={styles.orderBtnImage} onClick={() => jumpLink()}>
                 <img src={decorateData.orderBtnImage} alt='' />
              </View>
              <img src={lineImg} className={styles.lineImg} alt='' />
              <Text className={styles.activityTwoBtnsText}>
                {
                  activityInfo?.conditionType === 1 ?
                    `您距离下一个大奖还差${activityInfo.orderDifference || 0}单>>` :
                    activityInfo?.conditionType === 2 ?
                      `您距离下一个大奖还差${activityInfo.priceDifference || 0}元${activityInfo.orderDifference || 0}单>>` :
                      `您距离下一个大奖还差${activityInfo.priceDifference || 0}元>>`
                }
              </Text>
            </View>
          }
          { list.length > 2 &&
            <View className={styles.activityThreeBtns}>
              <View className={styles.orderBtnImage} onClick={() => jumpLink()}>
                 <img src={decorateData.orderBtnImage} alt='' />
              </View>
            <img src={lineImg} className={styles.lineImg} alt='' />
            <Text className={styles.activityTwoBtnsText}>
              {
                activityInfo?.conditionType === 1 ?
                  `您距离下一个大奖还差${activityInfo.orderDifference || 0}单>>` :
                  activityInfo?.conditionType === 2 ?
                    `您距离下一个大奖还差${activityInfo.priceDifference || 0}元${activityInfo.orderDifference || 0}单>>` :
                    `您距离下一个大奖还差${activityInfo.priceDifference || 0}元>>`
              }
            </Text>
          </View>
          }

        </View>
      }
      {
        !init && <div className={styles.empty}/>
      }
    </View>
  )
}

export default StepsGift
