import { http, userToken, isvStorage, global } from '@conecli/cone-render/api'

interface IsvTokenData {
  IsvToken: string;
  source: string;
}
// const apiUrl: string = 'https://lzkj-isv.isvjcloud.com/test/cc/interaction/v2/api/member';

// 生产
const apiUrl: string = 'https://lzcrm-rc.isvjcloud.com/prod/cc/interaction/member';

export {apiUrl};

const memberShopId: string = '1000002836';

class FloatCouponUtils {
  public isInitialized: boolean = false;
  private readonly apiUrl: string;
  private isvTokenData: IsvTokenData | null;
  static instance: FloatCouponUtils;
  private initPromise: Promise<IsvTokenData>;
  public readonly memberShopId: string ;

  constructor() {
    this.apiUrl = apiUrl;
    this.memberShopId = memberShopId;
    this.isvTokenData = null;
  }

  // 单例模式，确保整个应用中只有一个FloatCouponUtils实例
  static getInstance() {
    if (!this.instance) {
      this.instance = new FloatCouponUtils();
      isvStorage.setItem('floatCoupon_instance', this.instance);
    }
    return this.instance;
  }

  // 初始化方法，用于获取ISV Token，并标记为已初始化
  async init(): Promise<IsvTokenData> {
    if (!this.isInitialized && !this.initPromise) {
      this.initPromise = this.getISVToken().then(isvTokenData => {
        this.isvTokenData = isvTokenData;
        this.isInitialized = true;
        isvStorage.setItem('floatCoupon_instance', this);
        return isvTokenData;
      });
    }
    return this.initPromise;
  }

  // 获取ISV Token，如果在存储中不存在，则发起请求获取
  async getISVToken(): Promise<IsvTokenData> {
    if (!this.isvTokenData) {
      const IsvToken = (await this.sendRequestWithExponentialBackoff(userToken.getIsvToken));
      const source = userToken.getSource();
      return { IsvToken, source };
    } else {
      return this.isvTokenData;
    }
  };

  // 发送HTTP请求，带有自动重试逻辑
  async httpRequest(url: string, data: any = {}, header: any = {}, method: string = 'POST', maxRetries: number = 5, retries: number = 0) {
    const { data: response } = await http.request({
      url: this.apiUrl + url,
      method,
      data: {
        ...data,
        token: this.isvTokenData?.IsvToken,
        source: this.isvTokenData?.source,
        shopId: Number(global.info.queryInfo.shopId || this.memberShopId),
      },
      header: {
        'content-type': 'application/json',
        ...header,
      },
      credentials: 'omit'
    });

    // 如果请求失败，并且重试次数未达到最大值，则进行重试
    if (response.code !== 200) {
      if (retries < maxRetries) {
        retries++;
        const backoffTime = Math.pow(2, retries) * 1000;
        await new Promise(resolve => setTimeout(resolve, backoffTime));
        return this.httpRequest(url, data,header, method, maxRetries, retries);
      } else {
        return response;
      }
    }

    return response;
  }

  // 使用指数退避算法发送HTTP请求
  async sendRequestWithExponentialBackoff(fn: (val: any) => Promise<any>, data: any = {}, maxRetries: number = 5, retries: number = 0) {
    const response = await fn(data);
    // 如果请求失败，重试直到达到最大重试次数
    if (!response) {
      if (retries < maxRetries) {
        retries++;
        const backoffTime = Math.pow(2, retries) * 1000;
        await new Promise(resolve => setTimeout(resolve, backoffTime));
        return this.sendRequestWithExponentialBackoff(fn, data, maxRetries, retries);
      }
    }

    return response;
  }
}

export default FloatCouponUtils;
