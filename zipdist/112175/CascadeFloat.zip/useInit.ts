import React from 'react';
import CommonCascadeFloatUtils from './utils';
import { isvStorage } from '@conecli/cone-render/api'


// useInit 是一个自定义钩子，用于初始化并获取 CommonCascadeFloatUtils 类的单例实例
const useInit = () => {
  // 使用 useRef 来追踪初始化状态，确保初始化逻辑只执行一次
  const isInit = React.useRef(false);

  // lzUtils 状态用于存储 CommonCascadeFloatUtils 类的实例
  const [lzUtils, setLzUtils] = React.useState<any>(null);

  React.useEffect(() => {
    if (!isInit.current) {
      let utils = isvStorage.getItem('common_cascade_float_instance');
      if (!utils) {
        utils = CommonCascadeFloatUtils.getInstance();
      }

      if (!utils.isInitialized) {
        utils.init().then(() => {
          setLzUtils(utils);
          isInit.current = true;
        });
      } else {
        setLzUtils(utils);
        isInit.current = true;
      }
    }
  }, []);

  // 返回 CommonCascadeFloatUtils 实例
  return lzUtils;
};

export default useInit;
