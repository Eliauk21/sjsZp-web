import React, {useEffect, useState} from 'react'
import {View} from '@tarojs/components'
import {isvStorage, moduleUtil, util, http} from '@conecli/cone-render/api'
import RedEnvelopeRain from './components/RedEnvelopeRain/index'
import useInit from "./useInit";
import { apiUrl } from './utils'
import styles from './index.module.scss'

//陆泽会员卡片
const hongbaoyu = ({ floorData }) => {
  const lzUtils = useInit();

  const [memberConfig, setMemberConfig] = useState<any>({});
  // const [verification, setVerification] = useState<any>({
  //   code: 1,
  // });

  const [showModule, setShowModule] = useState(false);

  const fetchData = async (): Promise<void> => {
    if (lzUtils?.isInitialized) {
      isvStorage.setItem('lzUtilsHongbaoyu', lzUtils)
      try {
        const {data: memberConfig}: any = await lzUtils.httpRequest('/common/getMemberConfig', {
          keyName: 'hongbaoyu',
        });
        isvStorage.setItem('memberConfigHongbaoyu', JSON.parse(memberConfig.memberRenovationData));
        setMemberConfig(JSON.parse(memberConfig.memberRenovationData));
        console.log('JSON.parse(memberConfig.memberRenovationData)', JSON.parse(memberConfig.memberRenovationData));
        const {data: loginData}: any = await lzUtils.httpRequest('/common/login', {
          activityId: JSON.parse(memberConfig.memberRenovationData).activityInfo.id,
        });
        isvStorage.setItem('loginDataHongbaoyu', loginData);
        let header= {};
        header['Pin-Token'] = loginData.loginResponse.pinToken;
        header['Activity-Id'] = JSON.parse(memberConfig.memberRenovationData).activityInfo.id;
        header['Activity-Type'] = '10115';
        header['Prd'] = 'crm';
        isvStorage.setItem('headerHongbaoyu', header);

        // const res: any = await http.post(apiUrl + '/10115/thresholdVerification', {}, {
        //   credentials: 'omit',
        //   header: {
        //     'content-type': 'application/json',
        //     ...header
        //   },
        // });
        // setVerification(res.data.data);

        const {data} = await http.post(apiUrl +'/10115/decorationThresholdVerification', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          }
        });
        console.log('decorationThresholdVerification', data);
        setShowModule((data.data.code == 0) ? true : false)


        const activityVerification: any = await http.post(apiUrl + '/10115/thresholdVerification', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        const isFirstParticipate: any = await http.post(apiUrl + '/10115/isFirstParticipate', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        const todayVisitCount: any = await http.post(apiUrl + '/10115/todayVisitCount', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        if((data.data.code == 0) && activityVerification.data.data.code === 0 && isFirstParticipate.data.data && todayVisitCount.data.data == 0){
          openDialog();
        }
      } catch (e) {
        console.log(e)
      }
    }
  }

  const openDialog = () => {
    util.openDialog({
      className: styles['RedEnvelopeRainDialog'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <RedEnvelopeRain />,
    })
  }

  useEffect(() => {
    fetchData().then();
  }, [lzUtils?.isInitialized]);

  const rightPx = moduleUtil.getDataDefine(floorData, 'rightPx').text;
  const bottomPx = moduleUtil.getDataDefine(floorData, 'bottomPx').text;


  return (
    <View className={styles['hongbaoyu']}>
      {
        showModule && <View onClick={openDialog} style={{width: '3rem', height:'auto', position: 'fixed', bottom: `${bottomPx/20}rem`, right: `${rightPx/20}rem`, zIndex: '999999999'}}>
          <img style={{width: '3rem', height:'auto'}} src={memberConfig.floatingIcon || "//img10.360buyimg.com/imgzone/jfs/t1/279408/16/20529/231087/67fe1ad5Fc11d8ecf/191827f1f6885c26.png"} alt=""/>
        </View>
      }
    </View>
  )
}

export default hongbaoyu
