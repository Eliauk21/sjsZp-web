import React from 'react'
import { View } from '@tarojs/components'
import style from './index.module.scss'
import {util} from '@conecli/cone-render/api'

const ActivityRules = ( ) => {
  const closeDialog = () => {
    util.closeDialog()
  }

  return (
    <View className={style['EndGame']}>
      <View className={style['closeCon']}>
      <View className={style['no-prize-img-con']}>
        <img
          className={style['no-prize-img']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/281808/26/26716/1146053/680b62a5Ff49d864c/acbcee2593b4d981.png"
          alt=""/>
      </View>
    </View>
    </View>
  )
}

export default ActivityRules
