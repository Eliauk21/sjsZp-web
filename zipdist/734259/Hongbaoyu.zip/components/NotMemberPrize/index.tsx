import React, {useState} from 'react'
import { View } from '@tarojs/components'
import style from './index.module.scss'
import {isvStorage, shopMember, util, http} from '@conecli/cone-render/api'
import GiveUp from '../GiveUp/index'
import { apiUrl } from '../../utils'

const { oneKeyJoinMember } = shopMember

const ActivityRules = ({draw}) => {

  const lzUtils = isvStorage.getItem('lzUtilsHongbaoyu');
  const header = isvStorage.getItem('headerHongbaoyu');
  const memberConfig = isvStorage.getItem('memberConfigHongbaoyu');
  const loginDataHongbaoyu = isvStorage.getItem('loginDataHongbaoyu');

  const getBeaconBehaviors = () => {
    let opid = null;
    let token = null;

    // 安全解析
    if (memberConfig && memberConfig.activityInfo) {
      opid = memberConfig.activityInfo?.id || null;
    }
    if (loginDataHongbaoyu && loginDataHongbaoyu.loginResponse) {
      token = loginDataHongbaoyu.loginResponse.pinToken;
    }
    try {
      lzUtils.httpRequestPoint({
        'Pin-Token': token,
        'Activity-Id': opid,
        'Activity-Type': '10015',
        'Template-Code': '',
        reserveJsVersion: '',
        reserveEnvInfo: '',
        reserveClientTyp: 'h5',
        reserveFlowType: '1',
        reserveIsvToken: token,
        isvToken: token,
      });
    } catch (e) {
      console.error("Beacon 发送异常:", e);
    }
  };

  const joinMember = async () => {
    if (lzUtils?.isInitialized) {
      try {
        const isJoinMemberSuccess = await oneKeyJoinMember()
        if (isJoinMemberSuccess) {
          getBeaconBehaviors();
          // 领奖
          const {data: prize}: any = await http.post(apiUrl + '/10115/receivePrize', {
            prizeId: draw.activityPrizeId,
            userPrizeId: draw.userPrizeId,
          }, {
            credentials: 'omit',
            header: {
              'content-type': 'application/json',
              ...header
            },
          });
          // const {data: prize}: any = await lzUtils.httpRequest('/10115/receivePrize', {
          //   prizeId: draw.activityPrizeId,
          //   userPrizeId: draw.userPrizeId,
          // }, header);
          if(prize.data.status == 2){
            util.showFailToast({
              title: prize.prizeContent,
              duration: 3000
            })
          }else if(prize.data.status == 1){
            closeDialog();
            util.showSuccessToast({
              title: "领取成功",
              duration: 3000
            })
          }
        } else {
          openGiveUp();
        }
      } catch (e) {
        console.log('e', e);
      }
    }
  }

  const closeDialog = () => {
    util.closeDialog()
  }

  const openGiveUp = () => {
    util.openDialog({
      className: style['GiveUp'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <GiveUp draw={draw} />,
    })
  }

  return (
    <View className={style['NotMemberPrize']}>
      <View className={style['closeCon']} onClick={openGiveUp}>
        <img
          className={style['close']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/278656/18/20743/4348/67fe1488Fc63aa14b/a6df13e6174c39d9.png" alt=""/>
      </View>
      <View className={style['not-member-prize-img-con']}>
        <img
          className={style['not-member-prize-img']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/278806/21/20339/180861/67fe15edFbbcdad1b/b70e544277a8701f.png" alt=""/>
        <View className={style['not-member-prizeName']} style={{ color: memberConfig.prizeColor}}>{`获得${draw.prizeName}`}</View>
        <img className={style['not-member-prizeImg']} src={draw.prizeImg}></img>
        <View className={style['not-member-getprize']} onClick={joinMember}></View>
        <View className={style['not-member-leave']} onClick={openGiveUp}></View>
      </View>
    </View>
  )
}

export default ActivityRules
