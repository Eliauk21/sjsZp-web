import React, {useState, useEffect, useRef, useCallback} from 'react'
import { View } from '@tarojs/components'
import {isvStorage, util, http} from '@conecli/cone-render/api'
import CongratsAward from '../CongratsAward/index'
import AwardRecords from '../AwardRecords/index'
import ActivityRules from '../ActivityRules/index'
import NoPrize from '../NoPrize/index'
import NotMemberPrize from '../NotMemberPrize/index'
import { apiUrl } from '../../utils'
import style from './index.module.scss'

// 定义常量
const IMAGE_URLS = {
  CLOSE: "//img10.360buyimg.com/imgzone/jfs/t1/278656/18/20743/4348/67fe1488Fc63aa14b/a6df13e6174c39d9.png",
  OPEN_PRIZE: "//img10.360buyimg.com/imgzone/jfs/t1/280225/4/27068/10475/680b2b99F6bbaf3cb/ab00a0d780cac7c2.png",
  OPEN_RULE: "//img10.360buyimg.com/imgzone/jfs/t1/275602/34/26839/10456/680b2b94Fb0144a2a/545eac32c4ac3e75.png",
  RAIN_BACKGROUND: "https://jconnect.oss-cn-hangzhou.aliyuncs.com/hongbaoyu/4(1).gif",
  BOTTOM: "//img10.360buyimg.com/imgzone/jfs/t1/281897/17/20842/316067/67fe1696F788ebf06/0e420cba9466405d.png",
};

// 定义常量
const DEFAULT_IMAGE_URLS = {
  RED_ENVELOPE_IMAGE: '//img10.360buyimg.com/imgzone/jfs/t1/224451/38/31267/152167/680b02d8Ffed85363/5295b610cc0aa53a.png',
  COVER_IMAGE: '//img10.360buyimg.com/imgzone/jfs/t1/283112/39/23742/565629/680b02d7F4196c7a6/b4c03dc34c420e5c.png',
  PLAY_AGAIN_BUTTON: '//img10.360buyimg.com/imgzone/jfs/t1/281501/6/26516/15648/680b02d9Fff1fe1bb/a43132a63186bedd.png',
  NO_CHANCE_BUTTON: '//img10.360buyimg.com/imgzone/jfs/t1/284135/40/26250/16581/680b02d8Ff9426a51/c53317dc06be21d2.png',
  START_BUTTON: '//img10.360buyimg.com/imgzone/jfs/t1/270423/4/28194/20943/680b02daF4814578e/ae21c5700708501a.png',
  ENTER_SHOP_BUTTON: '//img10.360buyimg.com/imgzone/jfs/t1/276463/4/27558/20067/680b02d9F475dcc23/cd5cb4f3d530a3b6.png',
};


// 定义类型
interface RedEnvelope {
  id: number;
  src: string;
  style: string;
}

const RedEnvelopeRain = () => {
  const redEnvelopeRainRef = useRef<any>();
  // 活动信息
  const lzUtils = isvStorage.getItem('lzUtilsHongbaoyu') || {};
  const [countdownImgs, setCountdownImgs] = useState<any>([]);
  const [activityInfo, setActivityInfo] = useState<any>({});
  const [isFirstParticipate, setIsFirstParticipate] = useState<any>();
  const [chanceNum, setChanceNum] = useState<any>();
  const [isMember, setIsMember] = useState<any>();

  const [endGame, setEndGame] = useState(false);
  // 游戏开始状态和结束状态
  const [gameStart, setGameStart] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  // 游戏准备
  const [readyTime, setReadyTime] = useState(3);
  // 进行游戏
  const [redEnvelopes, setRedEnvelopes] = useState<Array<RedEnvelope>>([])
  const [clickCount, setClickCount] = useState(0);
  const [gameTime, setGameTime] = useState<any>(null);

  const [isDone, setIsDone] = useState(false);
  const [isGameEnding, setIsGameEnding] = useState(false);

  const header = isvStorage.getItem('headerHongbaoyu');
  const memberConfig = isvStorage.getItem('memberConfigHongbaoyu');

  // 获取活动信息
  const getActivityInfo = async () => {
    const header = isvStorage.getItem('headerHongbaoyu');
    console.log('lzUtils', lzUtils);
    setGameTime(null);
    if (lzUtils?.isInitialized) {
      try {
        console.warn(header);
        const isFirstParticipateRes: any = await http.post(apiUrl + '/10115/isFirstParticipate', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        setIsFirstParticipate(isFirstParticipateRes.data.data);
        const countRes: any = await http.post(apiUrl + '/10115/chanceNum', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        setChanceNum(countRes.data.data);
        const activityInfoRes: any = await http.post(apiUrl + '/10115/activity', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        setActivityInfo(activityInfoRes.data.data);
        setGameTime(activityInfoRes.data.data.activityDuration);
        const isMemberRes: any = await http.post(apiUrl + '/10115/isMember', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        setIsMember(isMemberRes.data.data);
        // // 是否首次参与
        // const {data: isFirstParticipate}: any = await lzUtils.httpRequest('/10115/isFirstParticipate', {}, header);
        // setIsFirstParticipate(isFirstParticipate);
        // // 可抽奖次数
        // const {data: count}: any = await lzUtils.httpRequest('/10115/chanceNum', {}, header);
        // setChanceNum(count);
        // // 红包雨活动信息
        // const {data: activityInfo}: any = await lzUtils.httpRequest('/10115/activity', {}, header);
        // setActivityInfo(activityInfo);
        // setGameTime(activityInfo.activityDuration);
        // // 是否是会员
        // const {data: isMember}: any = await lzUtils.httpRequest('/10115/isMember', {}, header);
        // setIsMember(isMember);

        setIsDone(true);
      } catch (error) {
        console.log(error);
      }
    }
  };
  useEffect(() => {
    // 弹窗埋点
    http.post(apiUrl + '/10115/visitTrackEvent', {}, {
      credentials: 'omit',
      header: {
        'content-type': 'application/json',
        ...header
      },
    });
    // lzUtils.httpRequest('/10115/visitTrackEvent', {}, header);
    if(memberConfig?.countDown1 && memberConfig?.countDown2 && memberConfig?.countDown3){
      setCountdownImgs([
        memberConfig.countDown3,
        memberConfig.countDown2,
        memberConfig.countDown1,
      ])
    }
    getActivityInfo();
  }, [])

  // 游戏准备倒计时
  useEffect(() => {
    let readyCountDown;
    if(gameStart && readyTime > 0){
      readyCountDown = setTimeout(() => {
        setReadyTime((prev) => prev - 1);
      }, 1000);
    }
    return () => clearTimeout(readyCountDown);
  }, [readyTime, gameStart]);

  // 游戏进行中
  useEffect(() => {
    let gameCountDown;
    if(readyTime<=0){
      if(gameTime === null || gameTime > 0){
        if(gameTime ===null) return;
        gameCountDown = setTimeout(() => {
          setGameTime((prev) => prev - 1);
        }, 1000);
      } else {
        setIsGameEnding(true); // 进入游戏结束延迟阶段
        setEndGame(true); // 结束游戏图片
        // util.openDialog({
        //   className: style['EndGame'],
        //   maskCloseable: false,
        //   isCustom: true,
        //   hasFooter: false,
        //   bodyNode: <EndGame />,
        // })
        const timer = setTimeout(() => {
          setGameTime(null);
          triggerLottery(); // 2 秒后正式结束游戏
          clearTimeout(timer);
        }, 2000); // 延迟 2 秒
      }
    }
    return () => clearTimeout(gameCountDown);
  }, [gameTime, readyTime])

  // 状态定义
  const [showLimit, setShowLimit] = useState(false);
  const useThreshold = (props: any): boolean => {
    const { thresholdList } = props;
    // 通用门槛
    const commonWarnList: any = thresholdList?.filter((e: any): boolean => !e.type);
    const commonWarnLength: number = commonWarnList?.length;

    // 自定义门槛
    const thresholdWarnList: any = thresholdList?.filter((e: any): boolean => !!e.type);
    const thresholdWarnLength: number = thresholdWarnList?.length;

    if (commonWarnLength) {
      const warnMessage: any = thresholdList[0];
      util.openDialog({
        title: warnMessage.thresholdTitle,
        message: warnMessage.thresholdContent,
      })
      return false;
    }
    return !!(!commonWarnLength && thresholdWarnLength);
  };

  // 开始游戏
  const playGame = async () => {
    try {
      // 门槛校验
      const res = await http.post(apiUrl + '/10115/thresholdVerification', {}, {
        credentials: 'omit',
        header: {
          'content-type': 'application/json',
          ...header
        },
      });
      console.log('thresholdVerification', res);
      if (res.data.data.code === 0) {
        setGameStart(true);
      } else if (res.data.data.code === 3) {
        const thresholdList = [{
          thresholdTitle: '很遗憾',
          thresholdContent: '您不是参与此活动的指定人群',
        }];
        setShowLimit(useThreshold({
          thresholdList,
        }))
      } else if (res.data.data.code === 1) {
        const thresholdList = [{
          thresholdTitle: '抱歉，活动暂未开始',
          thresholdContent: `活动开始时间：${activityInfo.startTime}`,
        }];
        setShowLimit(useThreshold({
          thresholdList,
        }))
      } else if (res.data.data.code === 2) {
        const thresholdList = [{
          thresholdTitle: '抱歉，活动已结束',
          thresholdContent: '敬请关注其他活动',
        }];
        setShowLimit(useThreshold({
          thresholdList,
        }))
      }
    } catch (error: any) {
      if (error?.message) {
        util.showFailToast({
          title: error?.message,
          duration: 3000
        })
      }
    }

  };

  // 独立抽奖函数
  const triggerLottery = async () => {
    console.log('gameOver', clickCount);
    try {
      const { data: res }: any = await http.post(apiUrl + '/10115/lotteryDraw', { clickCount }, {
        credentials: 'omit',
        header: {
          'content-type': 'application/json',
          ...header
        },
      });
      console.log('抽奖结果:', res);
      await http.post(apiUrl + '/10115/trackEvent', {}, {
        credentials: 'omit',
        header: {
          'content-type': 'application/json',
          ...header
        },
      });

      // const res = await lzUtils.httpRequest('/10115/lotteryDraw', { clickCount }, header);
      // lzUtils.httpRequest('/10115/trackEvent', {}, header);
      setEndGame(false);
      if (!res.data.userPrizeId) {
        util.openDialog({
          className: style['NoPrize'],
          maskCloseable: false,
          isCustom: true,
          hasFooter: false,
          bodyNode: <NoPrize />,
        });
      } else if (isMember) {
        const { data: prizeRes }: any = await http.post(apiUrl + '/10115/receivePrize', {
          prizeId: res.data.activityPrizeId, userPrizeId: res.data.userPrizeId
        }, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        // const prizeRes = await lzUtils.httpRequest(
        //   '/10115/receivePrize',
        //   { prizeId: res.data.activityPrizeId, userPrizeId: res.data.userPrizeId },
        //   header
        // );
        if (prizeRes.data.status === 1) {
          util.openDialog({
            className: style['CongratsAward'],
            maskCloseable: false,
            isCustom: true,
            hasFooter: false,
            bodyNode: <CongratsAward draw={prizeRes.data} />,
          });
        }
      } else {
        util.openDialog({
          className: style['NotMemberPrize'],
          maskCloseable: false,
          isCustom: true,
          hasFooter: false,
          bodyNode: <NotMemberPrize draw={res.data} />,
        });
      }
      setGameStart(false);
    } catch (error) {
      console.error('抽奖失败:', error);
      setGameStart(false);
    }
  };
  // 活动结束 延迟2后监听不到gameOver，注掉
  // useEffect(() => {
  //   console.log('gameOver', gameOver);
  //   if(gameOver){
  //     closeDialog();
  //     // 抽奖
  //     lzUtils.httpRequest('/10115/lotteryDraw', {
  //       clickCount,
  //     }, header).then((res: any) => {
  //       lzUtils.httpRequest('/10115/trackEvent', {}, header);
  //       setIsGameEnding(false);
  //       if(!res.data.userPrizeId){
  //         util.openDialog({
  //           className: style['NoPrize'],
  //           maskCloseable: false,
  //           isCustom: true,
  //           hasFooter: false,
  //           bodyNode: <NoPrize />,
  //         })
  //       }else if(isMember){
  //         // 领奖
  //         lzUtils.httpRequest('/10115/receivePrize', {
  //           prizeId: res.data.activityPrizeId,
  //           userPrizeId: res.data.userPrizeId,
  //         }, header).then((prizeRes: any) => {
  //           if(prizeRes.data.status == 2){
  //             util.showFailToast({
  //               title: prizeRes.data.prizeContent,
  //               duration: 3000
  //             })
  //           }else if(prizeRes.data.status == 1){
  //             util.openDialog({
  //               className: style['CongratsAward'],
  //               maskCloseable: false,
  //               isCustom: true,
  //               hasFooter: false,
  //               bodyNode: <CongratsAward draw={prizeRes.data} />,
  //             })
  //           }
  //         })
  //       } else {
  //         util.openDialog({
  //           className: style['NotMemberPrize'],
  //           maskCloseable: false,
  //           isCustom: true,
  //           hasFooter: false,
  //           bodyNode: <NotMemberPrize draw={res.data} />,
  //         })
  //       }
  //     })
  //   }
  // }, [gameOver])

  let packetId = 0;

  useEffect(() => {
    let interval ;
    if(gameStart && readyTime<=0){
      interval = setInterval(() => {
        const size = (Math.random() * 10 + 100)/22;
        const randomLeft = Math.random() * 50
        const rotates = ['-15', '-30', '0'];
        let startLeft;
        let endLeft;
        const random = Math.floor(Math.random() * rotates.length)
        if(random == 0){
          startLeft = endLeft = randomLeft;
        } else if(random == 1){
          startLeft = randomLeft-20;
          endLeft = randomLeft;
        } else {
          startLeft = randomLeft+20;
          endLeft = randomLeft-20;
        }
        const rotate = rotates[random];

        setRedEnvelopes((prev) => [...prev, {
          id: packetId++,
          src: memberConfig.redEnvelope,
          style: `--start-left: ${startLeft}%;
          --end-left: ${endLeft}%;
              left: ${startLeft}%;
              top: -20%;
              padding: 0 0 1.5rem 1.5rem;
              animation-duration: ${Math.random() * 2 + 2}s;
              width: ${size}rem;
              height: ${size}rem;
              transform: rotate(${rotate}deg);`
        }]);
      }, 300)
    }
    return () => clearInterval(interval)
  }, [readyTime, gameStart])

  const [envelopId, setEnvelopId] = useState<number | undefined>();

  // 点击红包
  const handleClick = useCallback((e: any, id: number) => {
    e.stopPropagation();
    if (envelopId === id || isGameEnding) return; // 如果处于游戏结束延迟阶段，直接返回
    setEnvelopId(id);

    setRedEnvelopes((prevEnvelopes) =>
      prevEnvelopes.map((envelope) => {
        if (envelope.id === id) {
          const currentTransform = envelope.style.match(/transform:\s*([^;]+)/)?.[1] || '';
          return {
            ...envelope,
            style: envelope.style.replace(
              /transform:\s*[^;]+/,
              `transform: scale(1.5) ${currentTransform}; opacity: 0; transition: opacity 0.3s ease;`,
            ),
          };
        }
        return envelope;
      })
    );

    if (redEnvelopes.find((p) => p.id === id)) {
      setClickCount((prev) => prev + 1);
    }

    setTimeout(() => {
      setRedEnvelopes((prevEnvelopes) => prevEnvelopes.filter((p) => p.id !== id));
    }, 300);
  }, [envelopId, redEnvelopes, isGameEnding]);

  const closeDialog = () => {
    util.closeDialog()
  }

  const openPrizeDialog = () => {
    util.openDialog({
      className: style['AwardRecords'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <AwardRecords />,
    })
  }

  const openRuleDialog = () => {
    util.openDialog({
      className: style['ActivityRules'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <ActivityRules />,
    })
  }
  return (
    <View className={style['RedEnvelopeRain']} onClick={(e) => {e.stopPropagation()}}>
      {
        gameStart ? <View className={style['red-envelope-game-start']}>
            {
              readyTime > 0 && <View className={style['count-down-con']}>
                <img className={style['count-down']} src={countdownImgs[readyTime-1]} alt=""/>
              </View>
            }
            <View className={style['closeCon']} onClick={closeDialog}>
              <img
                className={style['close']}
                src={IMAGE_URLS.CLOSE} alt=""/>
            </View>
            {
              gameTime !== null && !endGame &&
              <View className={style['countdown-container']}>
                <View className={style['countdown-desc']}>倒计时：</View>
                <View className={style['countdown-circle']}>
                  <span className={style['countdown-text']}>{ gameTime }</span>
                </View>
                <View className={style['countdown-bar']}>
                  <View className={style['progress']} style={{width: `${gameTime*100/activityInfo.activityDuration}%`}}></View>
                </View>
              </View>
            }

            {
              gameTime !== null && !endGame &&
              <View className={style['collected-count']} style={{color: memberConfig.countColor}}>
                领取红包数：<span>{ clickCount }</span> 个
              </View>
            }
            <View className={style['collected-cover']}></View>
            <View className={style['red-envelope-game']}>
              {redEnvelopes.map((envelope) => (
                <View
                  key={envelope.id}
                  className={style['red-packet']}
                  style={envelope.style}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleClick(e, envelope.id);
                  }}>
                  <img
                    alt="红包"
                    style={{ width: '100%', height: 'auto' }}
                    src={memberConfig.redEnvelopeImage || DEFAULT_IMAGE_URLS.RED_ENVELOPE_IMAGE}
                  />
                </View>
              ))}
            </View>
            <img className={style['bg-img1']}
                 src={IMAGE_URLS.RAIN_BACKGROUND}
                 alt=""/>
            <img className={style['bg-img2']}
                 src={IMAGE_URLS.BOTTOM}
                 alt=""/>
            {
              endGame && <View className={style['no-prize-img-con']}>
                <img
                  className={style['no-prize-img']}
                  src="//img10.360buyimg.com/imgzone/jfs/t1/281808/26/26716/1146053/680b62a5Ff49d864c/acbcee2593b4d981.png"
                  alt=""/>
              </View>
            }
          </View>
          : <>
            {
              activityInfo.id &&
              <View className={`${style['red-envelope-ready-cover']} ${style['active']}`} ref={redEnvelopeRainRef}>
                <View className={style['closeCon']} onClick={closeDialog}>
                  <img
                    className={style['close']}
                    src={IMAGE_URLS.CLOSE} alt=""/>
                </View>
                {
                  !isFirstParticipate && <>
                    <View className={style['openPrizeCon']} onClick={openPrizeDialog}>
                      <img
                        className={style['openPrize']}
                        src={IMAGE_URLS.OPEN_PRIZE} alt=""/>
                    </View>
                    <View className={style['openRuleCon']} onClick={openRuleDialog}>
                      <img
                        className={style['openRule']}
                        src={IMAGE_URLS.OPEN_RULE} alt=""/>
                    </View>
                  </>
                }
                <View className={style['red-envelope-ready']}>
                  <img
                    alt=""
                    className={style['red-envelope-cover']}
                    src={memberConfig.coverImage || DEFAULT_IMAGE_URLS.COVER_IMAGE}
                  />
                  {
                    (!isFirstParticipate && chanceNum>0) && <View className={style['start-con']} onClick={playGame}>
                      <img
                        className={style['start']}
                        src={memberConfig.playAgainButton || DEFAULT_IMAGE_URLS.PLAY_AGAIN_BUTTON}  alt=""/>
                    </View>
                  }
                  {
                    (!isFirstParticipate && chanceNum<=0) && <View className={style['start-con']}>
                      <img
                        className={style['start']}
                        src={memberConfig.noChanceButton || DEFAULT_IMAGE_URLS.NO_CHANCE_BUTTON}  alt=""/>
                    </View>
                  }
                  {
                    isFirstParticipate && <View className={style['start-con']} onClick={playGame}>
                      <img
                        className={style['start']}
                        src={memberConfig.startButton || DEFAULT_IMAGE_URLS.START_BUTTON} alt=""/>
                    </View>
                  }
                  <View className={style['go-shop-con']} onClick={closeDialog}>
                    <img
                      className={style['go-shop']}
                      src={memberConfig.enterShopButton || DEFAULT_IMAGE_URLS.ENTER_SHOP_BUTTON} alt=""/>
                  </View>
                </View>
              </View>

            }
          </>


      }
    </View>
  )
}

export default RedEnvelopeRain
