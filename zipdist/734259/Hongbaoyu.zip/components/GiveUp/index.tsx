import React from 'react'
import { View } from '@tarojs/components'
import style from './index.module.scss'
import {isvStorage, util, http} from '@conecli/cone-render/api'
import NotMemberPrize from "../NotMemberPrize/index";
import { apiUrl } from '../../utils'

const GiveUp = ({draw}) => {
  const lzUtils = isvStorage.getItem('lzUtilsHongbaoyu');
  const header = isvStorage.getItem('headerHongbaoyu');

  const openNotMember = () => {
    util.openDialog({
      className: style['NotMemberPrize'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <NotMemberPrize draw={draw} />,
    })
  }

  const giveUp = async () => {
    if (lzUtils?.isInitialized) {
      try {
        const {data: giveUpData}: any = await http.post(apiUrl + '/10115/giveUp', {
          prizeId: draw.activityPrizeId,
          userPrizeId: draw.userPrizeId,
        }, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        // const {data: giveUpData}: any = await lzUtils.httpRequest('/10115/giveUp', {
        //   prizeId: draw.activityPrizeId,
        //   userPrizeId: draw.userPrizeId,
        // }, header);
        if(giveUpData.data){
          closeDialog();
          util.showSuccessToast({
            title: "已放弃领奖",
            duration: 3000
          })
        }
      } catch (error) {
        console.log(error);
      }
    }
  }

  const closeDialog = () => {
    util.closeDialog()
  }

  return (
    <View className={style['GiveUp']}>
      <img className={style['give-up-img']} src="https://img10.360buyimg.com/imgzone/jfs/t1/235552/22/7632/128782/657811e6F7cd05616/1006dc263b84f865.png" alt=""/>
      <View className={style['closeCon']} onClick={openNotMember}>
        <img
          className={style['close']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/278656/18/20743/4348/67fe1488Fc63aa14b/a6df13e6174c39d9.png" alt=""/>
      </View>
      <View className={style['give-up-con']}>
        <View className={style['give-up-title']}>提示</View>
        <View className={style['give-up-content']}>确认放弃领取？</View>
        <View className={style['give-up-btn']} onClick={giveUp}>放弃领取</View>
      </View>
    </View>
  )
}

export default GiveUp
