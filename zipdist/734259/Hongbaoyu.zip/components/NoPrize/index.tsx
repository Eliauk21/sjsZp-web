import React from 'react'
import { View } from '@tarojs/components'
import style from './index.module.scss'
import {util} from '@conecli/cone-render/api'

const ActivityRules = ( ) => {
  const closeDialog = () => {
    util.closeDialog()
  }

  return (
    <View className={style['NoPrize']}>
      <View className={style['closeCon']} onClick={closeDialog}>
        <img
          className={style['close']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/278656/18/20743/4348/67fe1488Fc63aa14b/a6df13e6174c39d9.png" alt=""/>
      </View>
      <View className={style['no-prize-img-con']} onClick={closeDialog}>
        <img
          className={style['no-prize-img']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/106258/28/53129/1101939/680b2c3aF00ad9875/4e7c66402034689b.png"
          alt=""/>
      </View>
    </View>
  )
}

export default ActivityRules
