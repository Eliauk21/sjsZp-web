import React from 'react'
import { View } from '@tarojs/components'
import style from './index.module.scss'
import {isvStorage, util} from "@conecli/cone-render/api";

const prizeTypes = [
  {
    value: 2,
    name: '京豆',
    content: '请至【我的】-【京豆】查看',
  },
  {
    value: 4,
    name: '积分',
    content: '请至【店铺】-【会员】查看',
  },
  {
    value: 1,
    name: '优惠券',
    content: '请至【我的】-【优惠券】查看',
  },
];

const CongratsAward = ({ draw }) => {
  const memberConfig = isvStorage.getItem('memberConfigHongbaoyu');

  const closeDialog = () => {
    util.closeDialog()
  }

  // 开发模块效果
  return (
    <View className={style['CongratsAward']}>
      <View className={style['closeCon']} onClick={closeDialog}>
        <img
          className={style['close']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/278656/18/20743/4348/67fe1488Fc63aa14b/a6df13e6174c39d9.png" alt=""/>
      </View>
      <View className={style['member-prize-img-con']}>
        <img
          className={style['member-prize-img']}
          src="//img10.360buyimg.com/imgzone/jfs/t1/281260/9/24692/486897/680b2e6cF91be76b8/380c937e33f322e8.png" alt=""/>
        <View className={style['member-prizeName']} style={{ color: memberConfig.prizeColor}}>{`获得${draw.prizeName}`}</View>
        <img className={style['member-prizeImg']} src={draw.prizeImg}></img>
        <View className={style['member-info1']}>{`${prizeTypes.find(v => v.value == draw.prizeType)?.name}将会自动发放到您的账户`}</View>
        <View className={style['member-info2']}>{prizeTypes.find(v => v.value == draw.prizeType)?.content}</View>
      </View>
    </View>
  )
}

export default CongratsAward
