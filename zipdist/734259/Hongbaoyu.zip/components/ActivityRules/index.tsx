import React, {useEffect, useRef, useState} from 'react'
import { View } from '@tarojs/components'
import style from './index.module.scss'
import {util, isvStorage, http} from '@conecli/cone-render/api'
import RedEnvelopeRain from "../RedEnvelopeRain";
import { apiUrl } from '../../utils'

const ActivityRules = () => {
  const ruleRef = useRef<any>();
  const [activityRule, setActivityRule] = useState<any>('');

  // 获取活动信息
  const getActivityInfo = async () => {
    const lzUtils = isvStorage.getItem('lzUtilsHongbaoyu');
    const header = isvStorage.getItem('headerHongbaoyu');
    if (lzUtils?.isInitialized) {
      try {
        // const {data: activityRule}: any = await lzUtils.httpRequest('/activity/common/getRule', {}, header, 'GET');
        const {data: activityRule}: any = await http.get(apiUrl + '/activity/common/getRule', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        setActivityRule(activityRule.data);
      } catch (error) {
        console.log(error);
      }
    }
  };
  useEffect(() => {
    getActivityInfo();
  }, [])

  // useEffect(() => {
  //   if(ruleRef && ruleRef.current && activityRule){
  //     ruleRef.current.innerHTML = activityRule;
  //   }
  // }, [activityRule])

  const openRedEnvelopeRainDialog = () => {
    util.openDialog({
      className: style['RedEnvelopeRainDialog'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <RedEnvelopeRain />,
    })
  }

  return (
    <View className={style['ActivityRules']} id="ActivityRules">
      <View className={style["close"]} onClick={openRedEnvelopeRainDialog}>
        <img className={style["close-img"]} src="//img10.360buyimg.com/imgzone/jfs/t1/278656/18/20743/4348/67fe1488Fc63aa14b/a6df13e6174c39d9.png" alt="" />
      </View>
      <img className={style["rule-bk"]} src="//img10.360buyimg.com/imgzone/jfs/t1/282109/35/26944/443741/680b3256F5818239a/5fb583f655e9dfe8.png" alt=""/>
      {/* <View className={style["content-con"]} ref={ruleRef} /> */}
      <View
        className={style["content-con"]}
        dangerouslySetInnerHTML={{ __html: activityRule.replaceAll('\n', '<br/>') }}
      />
    </View>
  )
}

export default ActivityRules
