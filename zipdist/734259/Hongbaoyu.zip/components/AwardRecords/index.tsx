import React, {useEffect, useState} from 'react'
import { View } from '@tarojs/components'
import style from './index.module.scss'
import {util, isvStorage, http} from '@conecli/cone-render/api'
import RedEnvelopeRain from "../RedEnvelopeRain";
import { apiUrl } from '../../utils'

const AwardRecords = ( ) => {
  const [prizes, setPrizes] = useState<any>([]);

  // 获取活动信息
  const getActivityInfo = async () => {
    const lzUtils = isvStorage.getItem('lzUtilsHongbaoyu');
    const header = isvStorage.getItem('headerHongbaoyu');
    if (lzUtils?.isInitialized) {
      try {
        // 中奖信息
        const {data: prizes}: any = await http.post(apiUrl + '/10115/userPrizes', {}, {
          credentials: 'omit',
          header: {
            'content-type': 'application/json',
            ...header
          },
        });
        // const {data: prizes}: any = await lzUtils.httpRequest('/10115/userPrizes', {}, header);
        setPrizes(prizes.data)
      } catch (error) {
        console.log(error);
      }
    }
  };
  useEffect(() => {
    getActivityInfo();
  }, [])


  const openRedEnvelopeRainDialog = () => {
    util.openDialog({
      className: style['RedEnvelopeRainDialog'],
      maskCloseable: false,
      isCustom: true,
      hasFooter: false,
      bodyNode: <RedEnvelopeRain />,
    })
  }

  // 开发模块效果
  return (
    <View className={style['AwardRecords']}>
      <View className={style["close"]} onClick={openRedEnvelopeRainDialog}>
        <img className={style["close-img"]} src="//img10.360buyimg.com/imgzone/jfs/t1/278656/18/20743/4348/67fe1488Fc63aa14b/a6df13e6174c39d9.png" alt="" />
      </View>
      <img className={style["rule-bk"]} src="//img10.360buyimg.com/imgzone/jfs/t1/273935/8/25859/438726/680b325aFe06289e9/d857b6ee434cc800.png" alt=""/>
      <View className={style["content-con"]}>{
        prizes.length > 0 ? <View className={style["content"]}>
          {
            prizes.map(item => (<View className={style["info"]}>
              <img src={item.prizeImg} alt="" className={style["show-img"]} />
              <View className={style["detail"]}>
                <View className={style["detailContent"]}>
                  <View className={style["name"]}>{ item.prizeName }</View>
                  <View className={style["status"]}>
                    {
                      item.receiveStatus == 1 ? <View className={style["green"]}>已发放</View>
                        : <View className={style["orange"]}>领取失败</View>
                    }
                  </View>
                </View>
                <View className={style["time"]}>获奖时间：{ util.dateFormat(item.createTime) }</View>
              </View>
            </View>))
          }
        </View> : <View className={style["no-data"]}>暂无获奖记录哦~</View>
      }</View>
    </View>
  )
}

export default AwardRecords
