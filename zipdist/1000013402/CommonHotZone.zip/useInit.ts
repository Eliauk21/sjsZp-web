import React from 'react';
import { isvStorage } from '@conecli/cone-render/api'

const useInit = () => {

  // lzUtils 状态用于存储 Utils 类的实例
  const [lzUtils, setLzUtils] = React.useState<any>(null);
  React.useEffect(() => {
    const waitForUtilsInstance = async () => {
      let instance = isvStorage.getItem('common_instance');
      while (!instance || !instance.isInitialized) { // 等待实例完全初始化
        await new Promise(resolve => setTimeout(resolve, 100));
        instance = isvStorage.getItem('common_instance');
      }
      return instance;
    };

    waitForUtilsInstance().then(utilsInstance => {
      setLzUtils(utilsInstance);
    });
  }, []);

  // 返回 Utils 实例
  return lzUtils;
};

export default useInit;
