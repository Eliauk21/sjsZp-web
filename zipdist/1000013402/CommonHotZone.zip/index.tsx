import React from 'react'
import { View } from '@tarojs/components'
import {device, jump, track} from '@conecli/cone-render/api'

import styles from './index.module.scss'
import useInit from "./useInit";


const CommonHotZone = ({floorData}) => {
  console.log(floorData)
  const lzUtils = useInit();

  const screenWidth = device.getScreenWidth()
  const [decorateData, setDecorateData] = React.useState<any>([]);
  const [init, setInit] = React.useState(false);
  const fetchData = async (): Promise<void> => {
    if (lzUtils?.isInitialized) {
      try {
        const res = await lzUtils.httpRequest('/common/getMemberConfig', {
          keyName: 'hotZone',
        });
        if (res.data.memberRenovationData) {
          const result = JSON.parse(res.data.memberRenovationData).filter((item: any) => item.limit === 0 || item.limitLevels.includes(res.data.level));
          setDecorateData(result);
          setInit(true);
        }
      } catch (e) {
        console.log(e)
      }
    }
  }

  const onClickLink = (url: string): void => {
    if(!url || !floorData){
      return
    }
    // 埋点数据
    const trackEventInfo = track.getIsvClickEventInfo(floorData)
    console.log('trackEventInfo:', trackEventInfo)
    // 跳转逻辑
    jump.business.jdJumpConfigUrl({ configDataType: 22, configDataValue: { linkUrl: url } }, trackEventInfo)
  }

  React.useEffect(() => {
    fetchData().then();
  }, [lzUtils?.isInitialized]);
  // 开发模块效果
  return (
    <View className={styles.preview}>
      {
        init && (
          <View className={styles.preview}>
            {decorateData.map((item: any, dataIndex: number) => (
              <View key={dataIndex} className={styles.previewItem}>
                {item.bg && <img src={item.bg} alt=""/>}
                {item.hotZoneList.length > 0 && item.hotZoneList.map((hotZone: any, index: number) => (
                  <View
                    key={index}
                    className={styles.hotZone}
                    style={{
                      left: `${hotZone.left * screenWidth / 375}px`,
                      top: `${hotZone.top  * screenWidth / 375}px`,
                      width: `${hotZone.width * screenWidth / 375}px`,
                      height: `${hotZone.height  * screenWidth / 375}px`,
                    }}
                    onClick={() => onClickLink(hotZone.url)}
                  />
                ))}
              </View>
            ))}
          </View>
        )
      }
      {
        !init && <div className={styles.empty}/>
      }
    </View>
  )
}

export default CommonHotZone
