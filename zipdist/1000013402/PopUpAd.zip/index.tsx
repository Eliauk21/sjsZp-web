import React, {useEffect, useRef} from 'react'
import {Icon, View} from '@tarojs/components'
import {isvStorage, jump, track, util} from '@conecli/cone-render/api'
import useInit from "./useInit";
import style from './index.module.scss'


//陆泽会员卡片
const PopUpAd = ({ floorData }) => {
  const lzUtils = useInit();
  // const [popInfo, setPopInfo] = React.useState({
  //   bg:'',
  //   link:'',
  // })

  // // 埋点
  // const trackingInfo = () => {
  //   lzUtils.httpRequest('/deco/api/c/enterShopPopUpScreen/addBuriedPoint', {
  //     activityId: popInfo?.id,
  //     shopId: lzUtils.shopId,
  //     trackingType: "CLICK_JUMP",
  //     otherInfo: popInfo?.popupRedirectUrl
  //   }, 'post')
  // }

  const trackEventInfo = track.getIsvClickEventInfo(floorData)
  const jdJumpWebUrl = (v) => {
    // trackingInfo();
    jump.business.jdJumpConfigUrl({ configDataType: 22, configDataValue: { linkUrl: v?.link } }, trackEventInfo)
  }


  const renderDialogBody = (v) => {
    return <View className={style['videoDemoModule']}>
      {/* 取代dialog的阴影区关闭弹窗；组件冒泡，触发弹窗的关闭事件 */}
      <View className={style['closeView']} onClick={closeDialog}></View>
      {
        (v?.bg) && <View className={style['imgCon']}>
          <img src={v?.bg} alt="" className={style['gifScss']}/>
          <View className={style['clickView']} onClick={()=>{jdJumpWebUrl(v)}}></View>
          <Icon type='cancel' className={style['closeBtn']} onClick={closeDialog}/>
        </View>
      }
    </View>
  }

  const openDialog = (v) => {
    util.openDialog({
      className: style['my-dialog'],
      maskCloseable: false,
      isCustom: true,
      bodyNode: renderDialogBody(v),
    })
  }

  const closeDialog = () => {
    util.closeDialog()
  }

  const fetchData = async (): Promise<void> => {
    if (lzUtils?.isInitialized) {
      try {
        const res: any = await lzUtils.httpRequest('/common/getMemberConfig', {
          keyName: 'popUpAd',
        });
        if (res.data.memberRenovationData) {
          const result = JSON.parse(res.data.memberRenovationData);
          // setPopInfo(result[0]);
          openDialog(result[0]);
        }
      } catch (e) {
        console.log(e)
      }
    }
  }

  useEffect(() => {
    fetchData().then();
  }, [lzUtils?.isInitialized]);


  return (
    <View className={style['PopUp']}>
    </View>
  )
}

export default PopUpAd
