import React from 'react';
import PopUpAdUtils from './utils';
import { isvStorage } from '@conecli/cone-render/api'


// useInit 是一个自定义钩子，用于初始化并获取 PopUpAdUtils 类的单例实例
const useInit = () => {
  // 使用 useRef 来追踪初始化状态，确保初始化逻辑只执行一次
  const isInit = React.useRef(false);

  // lzUtils 状态用于存储 PopUpAdUtils 类的实例
  const [lzUtils, setLzUtils] = React.useState<any>(null);

  React.useEffect(() => {
    if (!isInit.current) {
      let utils = isvStorage.getItem('pop_up_ad_instance');
      if (!utils) {
        utils = PopUpAdUtils.getInstance();
      }

      if (!utils.isInitialized) {
        utils.init().then(() => {
          setLzUtils(utils);
          isInit.current = true;
        });
      } else {
        setLzUtils(utils);
        isInit.current = true;
      }
    }
  }, []);

  // 返回 PopUpAdUtils 实例
  return lzUtils;
};

export default useInit;
