import React from 'react'
import { View } from '@tarojs/components'
import styles from './index.module.scss'
import useInit from "./useInit";
import {jump, track} from "@conecli/cone-render/api";
import { CustomScrollView } from '@conecli/cone-render/components';



const CommonPointsExchange = ({ floorData }) => {
  console.log(floorData)
  const lzUtils = useInit();
  const [decorateData, setDecorateData] = React.useState<any>(null);
  const [init, setInit] = React.useState(false);
  const [userLevel, setUserLevel] = React.useState(1);
  const [userPoints, setUserPoints] = React.useState(0);

  const fetchData = async () => {
    if (lzUtils?.isInitialized) {
      try {
        const res = await lzUtils.httpRequest('/common/getMemberConfig', {
          keyName: 'pointsExchange',
        });
        if (res.data.memberRenovationData) {
          setUserLevel(res.data.level);
          setUserPoints(res.data.userPoints)
          const result = JSON.parse(res.data.memberRenovationData);
          setDecorateData(result);
          setInit(true);
        }
      } catch (e) {
        console.log(e)
      }
    }
  }

  const getBtnText = (item) => {
    const points = item.levels.filter((e) => e.level === userLevel)[0]?.points;
    if (userPoints < points) {
      return `还差${points - userPoints}积分`
    } else {
      return '立即兑换'
    }
  }

  const onClickLink = (url) => {
    if(!url || !floorData){
      return
    }
    // 埋点数据
    const trackEventInfo = track.getIsvClickEventInfo(floorData)
    console.log('trackEventInfo:', trackEventInfo)
    // 跳转逻辑
    jump.business.jdJumpConfigUrl({ configDataType: 22, configDataValue: { linkUrl: url } }, trackEventInfo)
  }

  React.useEffect(() => {
    fetchData().then();
  }, [lzUtils?.isInitialized]);
  // 开发模块效果
  return (
    <View>
      {
        init && (
          <View
            className={styles.preview}
            style={
              {
                '--bg-img': `url(${decorateData.bg})`,
              } as any
            }
          >
            <CustomScrollView
              scrollX
              scrollWithAnimation
              className={styles['my-view']}
            >
              <View className={styles.items}>
                {decorateData.activityList.map((item, index) => (
                  <View key={index} className={styles.item}>
                    <View key={index} className={styles.itemImg}>
                      <img src={item.bg} alt=""/>
                    </View>
                    <View
                      style={
                        {
                          '--btn-color': decorateData.btnColor,
                          '--btn-bg': decorateData.btnBg,
                        } as any
                      }
                      className={styles.itemBtn}
                      onClick={() => {
                        const points = item.levels.filter((e) => e.level === userLevel)[0]?.points;
                        if (userPoints < points) {
                          return
                        }
                        onClickLink(item.activityUrl)
                      }}
                    >
                      {getBtnText(item)}
                    </View>
                  </View>
                ))}
              </View>
            </CustomScrollView>

            <View className={styles.tip} style={{
              color: decorateData.tipColor,
            }}>{`< 左右滑动查看更多 >`}</View>
          </View>
        )
      }
      {
        !init && (
          <div
            className={styles.preview}
          >
            <CustomScrollView
              scrollX
              scrollWithAnimation
              className={styles['my-view']}
            >
              <div className={styles.items}>
                {Array.from({length: 4}).map((_, index) => (
                  <div key={index} className={styles.item}>
                    <div key={index} className={styles.itemImgEmpty}>
                      <div className={styles.img}/>
                    </div>
                    <div
                      style={
                        {
                          '--btn-color': 'white',
                          '--btn-bg': '#1677FF',
                        } as any
                      }
                      className={styles.itemBtn}
                    >
                      立即兑换
                    </div>
                  </div>
                ))}
              </div>
            </CustomScrollView>
            <div
              className={styles.tip}
            >{`< 左右滑动查看更多 >`}</div>
          </div>
        )
      }
    </View>
  )
}

export default CommonPointsExchange
