import React, {useEffect, useState, useRef} from 'react'
import { Text, View, Image } from '@tarojs/components'
import styles from './index.module.scss'
import {moduleUtil, track, jump, isvStorage, http, shopMember} from '@conecli/cone-render/api'
import useInit from "./useInit";

const { oneKeyJoinMember } = shopMember

const FloatCoupon = ({ floorData }) => {
  const lzUtils = useInit();
  const [memberConfig, setMemberConfig] = useState<any>({});
  const [eleTag, setEleTag] = useState<any>(false);
  const [countDown, setCountDown] = useState<any>();
  const [loginData, setLoginData] = useState<any>({});

  const fetchData = async (): Promise<void> => {
    if (lzUtils?.isInitialized) {
      try {
        const {data: memberConfig}: any = await lzUtils.httpRequest('/common/getMemberConfig', {
          keyName: 'floatCoupon',
        });
        const memberConfigData = JSON.parse(memberConfig.memberRenovationData);
        setMemberConfig(memberConfigData);

        const {data: loginData}: any = await lzUtils.httpRequest('/common/login', {});
        setLoginData(loginData);
        // 关闭横幅
        const {data: ifClose}: any = await lzUtils.httpRequest('/common/ifClose', {
          encryptPin: loginData.loginResponse.encryptPin
        });
        setEleTag(ifClose);
        // 埋点
        let data = {
          type: 'FloatCoupon',
          position: '0',
          action: '1',
          encryptPin: loginData.loginResponse.encryptPin
        }
        await lzUtils.httpRequest('/common/addPoint', data);

        const countdownTimeData = memberConfigData.countdownTime * 60000

        setCountDown(memberConfigData.countdownTime*60);
        if(memberConfigData.closeMode == 2){
          setTimeout(() => {
            setEleTag(false);
          }, 5000)
        }

        if(memberConfigData.countdownMode == 1){
          setTimeout(() => {
            setEleTag(false);
          }, countdownTimeData)
        }
      } catch (e) {
        console.log(e)
      }
    }
  }

  // 数据埋点方法
  const trackingInfo = async (position, action='1') => {
    try {
      let data = {
        type: 'FloatCoupon',
        position,
        action,
        encryptPin: loginData.loginResponse.encryptPin
      }
      await lzUtils.httpRequest('/common/addPoint', data);
    } catch (error) {
      console.log('error', error);
    }
  }

  useEffect(() => {
    fetchData().then();
  }, [lzUtils?.isInitialized]);

  const intervalRef: any = useRef(); // 使用 ref 保存 interval ID
  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setCountDown((prev) => prev - 1);
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);
  useEffect(() => {
    if (countDown <= 0 && intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, [countDown]);

  const timeHandle = (totalSeconds: number): string => {
    const minutes = Math.floor(totalSeconds / 60); // 计算总分钟数
    const seconds = totalSeconds % 60; // 剩余的秒数

    // 格式化输出，补零
    const formattedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
    const formattedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;

    return `${formattedMinutes}:${formattedSeconds}`;
  };

  const closeEleTag = async () => {
    // 关闭埋点
    await trackingInfo('1')
    setEleTag(false);
  };

  // 跳转指定页面
  const jdJumpWebUrl = (linkUrl: string) => {
    jump.business.jdJumpConfigUrl({ configDataType: 22, configDataValue: { linkUrl } }, {})
  }

  function convertUrlForm(url) {
    const [baseUrl, otherString] = url.split('&path=');
    const [pathString, paramString] = otherString.split('&param=');
    return `${baseUrl}&path=${encodeURIComponent(pathString)}&param=${encodeURIComponent(paramString)}`
  }


  // 跳转指定页面
  const jdMiniumpWebUrl = (linkUrl: string) => {
    jump.business.jdJumpConfigUrl({ configDataType: 22, configDataValue: { linkUrl: convertUrlForm(linkUrl) } }, {})
  }


  const gotoLink = async () => {
    // 跳转埋点
    await trackingInfo('2')
    if(([1,5].includes(memberConfig.redirectMode) || (memberConfig.redirectMode == 2 && memberConfig.activityUrlMode == 1)) && memberConfig.redirectUrl){
      jdJumpWebUrl(memberConfig.redirectUrl);
    }
    if((memberConfig.redirectMode == 2 && memberConfig.activityUrlMode == 2) && memberConfig.redirectUrl){
      jdMiniumpWebUrl(memberConfig.redirectUrl);
    }
    if(memberConfig.redirectMode == 3 && memberConfig.shopLinkMode == 1){
      jdJumpWebUrl(`https://shop.m.jd.com/shop/home?shopId=${lzUtils.memberShopId}`);
    }
    if(memberConfig.redirectMode == 3 && memberConfig.shopLinkMode == 2){
      jdJumpWebUrl(`https://shop.m.jd.com/member/home?shopId=${lzUtils.memberShopId}`);
    }
    if(memberConfig.redirectMode == 4){
      const isJoinMemberSuccess = await oneKeyJoinMember()
      if (isJoinMemberSuccess) {
        console.log('加入会员成功');
      }
    }
  }

  const distanceData = moduleUtil.getDataDefine(floorData, 'distanceData').text;

  // 开发模块效果
  return (
    <View>{
      eleTag && <View
        className={styles['floatCoupon']}
        style={{
          ...(memberConfig.positionMode == '1' ? {top: `${distanceData/20}rem`} : {}),
          ...(memberConfig.positionMode == '2' ? {bottom: `${distanceData/20}rem`} : {}),
        }}
      >
        <img className={styles['floatCouponBacImg']} src={memberConfig.backgroundImage} alt=""/>
        {
          memberConfig.countdownMode == '1' ? <View style={{color: memberConfig.backgroundTextColor}} className={styles['floatCouponText']}>
            {memberConfig.backgroundText}
          </View> : <View style={{color: memberConfig.backgroundTextColor}} className={styles['verticalCenter']}>
            {memberConfig.backgroundText}
          </View>
        }
        <View style={{color: memberConfig.backgroundTextColor}} className={styles['countDown']}>
          {(memberConfig.countdownMode == '1' && countDown) ? `倒计时：00:${timeHandle(countDown)}` : ''}
        </View>
        <View className={styles['floatCouponBtn']} onClick={gotoLink}>
          <img className={styles['floatCouponBtnImg']} src={memberConfig.buttonImage} alt=""/>
          <View className={styles['floatCouponBtnText']} style={{color: memberConfig.buttonTextColor}}>
            {memberConfig.buttonText}
          </View>
        </View>
        {memberConfig.closeMode == 1 ? (
          <Image onClick={closeEleTag}
                 className={styles['closeIcon']}
                 src="//img10.360buyimg.com/imgzone/jfs/t1/287374/6/8424/953/683583b3Ff6e961fd/fe903101fe4f580b.png"
          />
        ) : (
          <View className={styles['close-button']} onClick={closeEleTag}>
            ×
            <svg className={styles['progress-ring']} width="24" height="24">
              <circle
                className={styles['progress-ring-circle']}
                stroke="#fff"
                strokeWidth="1"
                fill="transparent"
                r="11"
                cx="12"
                cy="12"
              />
            </svg>
          </View>
        )}
      </View>
    }</View>
  )
}

export default FloatCoupon
