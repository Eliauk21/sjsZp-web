import React from 'react'
import {device, jump, track} from '@conecli/cone-render/api'
import { Swiper, SwiperItem, View } from '@tarojs/components'
import styles from './index.module.scss'
import useInit from "./useInit";


const CommonCascader = ({ floorData }) => {
  console.log(floorData)

  const screenWidth = device.getScreenWidth()

  const lzUtils = useInit();
  const [decorateData, setDecorateData] = React.useState<any>([]);
  const [init, setInit] = React.useState(false);
  const fetchData = async () => {
    if (lzUtils?.isInitialized) {
      try {
        const res = await lzUtils.httpRequest('/common/getMemberConfig', {
          keyName: 'swiper',
        });
        if (res.data.memberRenovationData) {
          const result = JSON.parse(res.data.memberRenovationData);
          setDecorateData(result);
          setInit(true);
        }
      } catch (e) {
        console.log(e)
      }
    }
  }
  const onClickLink = (url) => {
    if(!url || !floorData){
      return
    }
    // 埋点数据
    const trackEventInfo = track.getIsvClickEventInfo(floorData)
    console.log('trackEventInfo:', trackEventInfo)
    // 跳转逻辑
    jump.business.jdJumpConfigUrl({ configDataType: 22, configDataValue: { linkUrl: url } }, trackEventInfo)
  }

  React.useEffect(() => {
    fetchData().then();
  }, [lzUtils?.isInitialized]);
  // 开发模块效果
  return (
    <View className={styles.preview}>
      {
        init && (
          <View>
            <Swiper autoplay interval={2500} style={{ overflow: 'unset', height: '100%' }}>
              {decorateData.map((v, i) => (
                <SwiperItem key={i}>
                  {v.bg && (
                    <View className={styles.previewItem}>
                      <img alt="" src={v.bg} />
                      {v.hotZoneList.length > 0 && v.hotZoneList.map((hotZone, index) => (
                        <View
                          key={index}
                          className={styles.hotZone}
                          style={{
                            left: `${hotZone.left * screenWidth / 375}px`,
                            top: `${hotZone.top  * screenWidth / 375}px`,
                            width: `${hotZone.width * screenWidth / 375}px`,
                            height: `${hotZone.height  * screenWidth / 375}px`,
                          }}
                          onClick={() => onClickLink(hotZone.url)}
                        />
                      ))}
                    </View>
                  )}
                </SwiperItem>
              ))}
            </Swiper>
          </View>
        )
      }
      {
        !init && <div className={styles.empty}/>
      }
    </View>
  )
}

export default CommonCascader
