import React from 'react'
import { Text, View } from '@tarojs/components'
import {  track, jump, shopMember, environment } from '@conecli/cone-render/api'
import useInit from "./useInit";
import { CustomScrollView } from '@conecli/cone-render/components'
import styles from './index.module.scss'
//陆泽会员卡片
const CommonMemberCard = ({ floorData }) => {
  const isJdApp = environment.judge.isJdApp
  const { ShopMemberCardNodeType } = shopMember;
  const lzUtils = useInit();
  const [memberData, setMemberData] = React.useState<any>({});
  const [decorateData, setDecorateData] = React.useState<any>(null);
  const [init, setInit] = React.useState(false);


  //点击会员权益
  const onRule = (): void => {
    if (!floorData) {
      return
    }
    const trackEventInfo = track.getClickEventInfo(floorData)
    jump.business.jdJumpToShopMemberRule(trackEventInfo);
  }

  //跳转积分明细
  const jumpPoint = (): void => {
    if (!floorData) {
      return
    }
    const trackEventInfo = track.getClickEventInfo(floorData)
    jump.business.jdJumpToShopMemberPointDetail(trackEventInfo);
  }

  const fetchData = async (): Promise<void> => {
    if (lzUtils?.isInitialized) {
      try {
        const res: any = await lzUtils.httpRequest('/common/getMemberConfig', {
          keyName: 'membershipCard',
        });
        if (res.data.memberRenovationData) {
          setMemberData(res.data);
          const result = JSON.parse(res.data.memberRenovationData as string);
          setDecorateData(result);
          setInit(true);
        }
      } catch (e) {
        console.log(e)
      }
    }
  }

  const onClickLink = (url: string): void => {
    if(!url || !floorData){
      return
    }
    // 埋点数据
    const trackEventInfo = track.getIsvClickEventInfo(floorData)
    console.log('trackEventInfo:', trackEventInfo)
    // 跳转逻辑
    jump.business.jdJumpConfigUrl({ configDataType: 22, configDataValue: { linkUrl: url } }, trackEventInfo)
  }

  const changeNickName = () => {
    if(jump.business?.jdJumpToShopMemberInfo){
      jump.business?.jdJumpToShopMemberInfo()
    }
  };


  React.useEffect(() => {
    console.log('isJdApp',isJdApp)
    fetchData().then();
  }, [lzUtils?.isInitialized]);
  return (
    <View>
      {
        init && (
          <View className={styles.preview}>
            {
              decorateData.showKv && (
                <View className={styles.img} id={ShopMemberCardNodeType.CARD_BANNER}>
                  <img src={decorateData.kv} alt="" className={styles.img}/>
                </View>
              )
            }

            {
              decorateData.showKv && (
                <View
                  className={styles.rule}
                  style={{
                    backgroundColor: decorateData.ruleBtnBg,
                    color: decorateData.ruleBtnColor,
                  }}
                  id={ShopMemberCardNodeType.MEMBERSHIP_RULE_ENTRANCE}
                  onClick={onRule}
                >
                  会员权益规则
                </View>
              )
            }

            <View
              className={styles.member}
              style={
                {
                  '--member-bg': `url(${decorateData.memberLevels[memberData.level - 1].levelInfo.bg || ''})`,
                } as any
              }
            >
            <View className={styles.memberInfo}>
              <View className={styles.memberInfoLeft}>
                <View className={styles.avatar}>
                  <img src={memberData.loginResponse.avatar} alt=""/>
                </View>
                <View>
                  <View
                    className={styles.name}
                    style={{
                      color: decorateData.memberLevels[memberData.level - 1].levelInfo.nameOrLevelColor || decorateData.nameOrLevelColor,
                    }}
                  >
                    {memberData.loginResponse.nickname}
                    {
                      decorateData.showMemberEdit && isJdApp && <>{decorateData.iconType && decorateData.iconType == 1 ? (
                        <span onClick={changeNickName}
                              className={`${styles.memberIconEdit} ${styles.iconfont}`}
                              style={{ color: decorateData.editIconColor, fontSize: 12 }}>&#xe717;</span>
                      ) : decorateData.iconImg ? (
                          <view onClick={changeNickName}>
                            <img src={decorateData.iconImg} alt="" style={{ width: 11, height: 11, marginLeft: '.3rem' }} />
                          </view>
                      ) : ''}</>
                    }
                  </View>
                  <View
                    className={styles.points}
                    style={{
                      backgroundColor: decorateData.memberLevels[memberData.level - 1].levelInfo.pointBg || decorateData.pointBg,
                      color: decorateData.memberLevels[memberData.level - 1].levelInfo.pointColor || decorateData.pointColor,
                    }}
                    id={ShopMemberCardNodeType.MEMBERSHIP_POINT}
                    onClick={jumpPoint}
                  >
                    我的积分: {memberData.userPoints}
                  </View>
                </View>
              </View>
              <View>
                <View className={styles.levelLabel} id={ShopMemberCardNodeType.CARD_NAME} style={{
                  color: decorateData.memberLevels[memberData.level - 1].levelInfo.tipColor || decorateData.tipColor,
                }}>当前会员等级</View>
                <View
                  className={styles.level}
                  id={ShopMemberCardNodeType.MEMBERSHIP_LEVEL}
                  style={{
                    color: decorateData.memberLevels[memberData.level - 1].levelInfo.nameOrLevelColor || decorateData.nameOrLevelColor,
                  }}
                >
                  {memberData.levelName}
                </View>
                {
                  decorateData.showMemberLevel && <View
                    className={styles.levelNumber}
                    style={{
                      color: decorateData.memberLevelColor,
                    }}
                  >
                    LV{memberData.level}
                  </View>
                }
              </View>
            </View>
              {decorateData.swiperDircet == 1 ? (
                <CustomScrollView
                  scrollX
                  scrollWithAnimation
                  className={styles['my-view']}
                >
                  <View className={styles.icons}>
                    {decorateData.memberLevels[memberData.level - 1].levelInfo.iconList.map((_, index) => (
                      <View className={styles.icon} key={index} onClick={() => onClickLink(_.url)}>
                        <img   src={_.icon} alt=""/>
                      </View>

                    ))}
                  </View>
                </CustomScrollView>
              ) : (
                <View className={styles.iconsFlex}>
                  {decorateData.memberLevels[memberData.level - 1].levelInfo.iconList.map((_, index) => (
                    <View className={styles.icon} key={index} onClick={() => onClickLink(_.url)}>
                      <img key={index} className={styles.icon} src={_.icon} alt="" />
                    </View>
                  ))}
                </View>
              )}
            </View>
          </View>
        )
      }
      {
        !init && (
          <View className={styles.preview}>
            <View className={[styles.img, styles.imgDefault].join(' ')}></View>
            <View
              className={styles.rule}
            >
              会员权益规则
            </View>

            <View
              className={styles.member}
            >
              <View className={styles.memberInfo}>
                <View className={styles.memberInfoLeft}>
                  <View className={styles.avatar}/>
                  <View>
                    <View
                      className={styles.name}
                    >
                      会员名称
                    </View>
                    <View
                      className={styles.points}
                    >
                      我的积分: 9999
                    </View>
                  </View>
                </View>
                <View>
                  <View
                    className={styles.levelLabel}
                  >
                    当前会员等级
                  </View>
                  <View
                    className={styles.level}
                  >
                    会员等级
                  </View>
                </View>
              </View>
              <View className={styles.icons}>
                {Array.from({length: 5}).map((_, index) => (
                  <img
                    key={index}
                    className={styles.icon}
                    src="//img10.360buyimg.com/imgzone/jfs/t1/225218/29/9521/3836/658a6ec8Fe6293b85/2e1e9bc2303710a3.png"
                    alt=""
                  />
                ))}
              </View>
            </View>
            {/*卡面背景图*/}
            <View id={ShopMemberCardNodeType.CARD_BANNER}></View>
            {/*会员体系名称*/}
            <View id={ShopMemberCardNodeType.CARD_NAME}></View>
            {/*会员等级*/}
            <Text id={ShopMemberCardNodeType.MEMBERSHIP_LEVEL}></Text>
            {/*会员规则入口页面*/}
            <View id={ShopMemberCardNodeType.MEMBERSHIP_RULE_ENTRANCE}></View>
            {/*会员积分*/}
            <Text id={ShopMemberCardNodeType.MEMBERSHIP_POINT}></Text>
          </View>

        )
      }
    </View>
  )
}

export default CommonMemberCard
